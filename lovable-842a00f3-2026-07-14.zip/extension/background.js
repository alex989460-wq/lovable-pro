console.log("[Background] Lovable Pro service worker started");

// ============================================================
// License heartbeat
// Polls /api/public/validate-license on a jittered ~5min schedule so admin-
// side changes (expiry, revoke, pause, time bumps) propagate to every device
// within minutes — without flooding the backend.
// ============================================================
const MXX_LICENSE_API = "https://project--842a00f3-69ac-4b4a-a0fa-09ea7bb38242-dev.lovable.app/api/public/validate-license";
const MXX_HEARTBEAT_ALARM = "mxx-license-heartbeat";
const MXX_LICENSE_KEYS = [
  "mxx_license_key",
  "mxx_license_activated_at",
  "mxx_license_expires_at",
  "mxx_license_last_validated_at",
  "mxx_lifetime",
  "mxx_expires_at",
  "ql_license_valid",
  "ql_license_key",
  "ql_license_status",
  "ql_session_id",
  "ql_user_name",
  "ql_activated_at",
  "ql_expires_at",
  "lovable_token",
  "lovable_projectId",
  "lovable_browserSessionId",
  "ql_pending_new_project",
];

function mxxClearLicenseAndNotify(reason) {
  chrome.storage.local.set({ mxx_license_disconnect_reason: reason || "invalid" }, function () {
    chrome.storage.local.remove(MXX_LICENSE_KEYS, function () {
      chrome.tabs.query({ url: LOVABLE_TAB_URLS }, function (tabs) {
        (tabs || []).forEach(function (tab) {
          if (!tab || !tab.id) return;
          try { chrome.tabs.sendMessage(tab.id, { action: "qlLicenseDisconnected", reason: reason || "invalid" }, function () {}); } catch (e) {}
        });
      });
    });
  });
}

function mxxGetDeviceId() {
  return new Promise(function (resolve) {
    chrome.storage.local.get(["mxx_device_id"], function (res) {
      if (res.mxx_device_id) return resolve(res.mxx_device_id);
      var id = (crypto && crypto.randomUUID && crypto.randomUUID()) ||
        "dev-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10);
      chrome.storage.local.set({ mxx_device_id: id }, function () { resolve(id); });
    });
  });
}

async function mxxHeartbeat() {
  try {
    var stored = await new Promise(function (r) {
      chrome.storage.local.get(MXX_LICENSE_KEYS, function (x) { r(x || {}); });
    });
    if (!stored.mxx_license_key) return; // nothing to check

    // Local-expiry short-circuit (no network).
    var exp = stored.mxx_license_expires_at ? Date.parse(stored.mxx_license_expires_at) : 0;
    if (exp && exp < Date.now()) {
      mxxClearLicenseAndNotify("expired");
      return;
    }

    // Tamper check before every network call. If the guard locks, skip.
    try {
      if (self.MxxTamperGuard) {
        var ok = await self.MxxTamperGuard.run();
        if (ok === false) return;
      }
    } catch (e) {}

    var device_id = await mxxGetDeviceId();
    var fingerprint = (self.MxxTamperGuard && self.MxxTamperGuard.manifestFingerprint)
      ? self.MxxTamperGuard.manifestFingerprint()
      : { name: null, version: null };

    var resp = await fetch(MXX_LICENSE_API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        key: stored.mxx_license_key,
        device_id: device_id,
        heartbeat: true,
        manifest_name: fingerprint.name,
        manifest_version: fingerprint.version,
      }),
    });
    var body = {};
    try { body = await resp.json(); } catch (e) {}

    if (resp.ok && body && body.valid === true) {
      // Verify Ed25519 signature — forged or stale replies trip lockdown.
      if (self.MxxTamperGuard && self.MxxTamperGuard.verifyLicenseSignature) {
        var sigReason = await self.MxxTamperGuard.verifyLicenseSignature({
          key: body.key,
          device_id: device_id,
          expires_at: body.expires_at,
          activated_at: body.activated_at,
          issued_at: body.issued_at,
          status: "active",
          signature: body.signature,
        });
        if (sigReason && sigReason !== "missing_signature") {
          self.MxxTamperGuard.lockdown(sigReason);
          return;
        }
      }
      chrome.storage.local.set({
        mxx_license_expires_at: body.expires_at || stored.mxx_license_expires_at,
        mxx_license_activated_at: body.activated_at || stored.mxx_license_activated_at,
        mxx_lifetime: body.lifetime === true || body.duration_type === "lifetime",
        mxx_expires_at: body.expires_at || null,
        ql_user_name: body.user_name || stored.ql_user_name || "Lovable Pro User",
        ql_activated_at: body.activated_at || stored.ql_activated_at || null,
        ql_expires_at: body.expires_at || null,
        mxx_license_last_validated_at: new Date().toISOString(),
        mxx_support_whatsapp_url: body.support && body.support.whatsapp_url || null,
        mxx_support_contact_url: body.support && body.support.contact_url || null,
        mxx_support_contact_label: body.support && body.support.contact_label || null,
      });
    } else if (resp.status === 403 || resp.status === 404) {
      // tamper_revoked / expired / revoked / paused / device_mismatch / not_found -> lock.
      if (body && body.reason === "tamper_revoked" && self.MxxTamperGuard) {
        self.MxxTamperGuard.lockdown("server_tamper_revoked");
      } else {
        mxxClearLicenseAndNotify((body && body.reason) || "invalid");
      }
    }
    // Other failures (network, 5xx): trust local copy until next tick.
  } catch (e) {
    // Network/transient errors are non-fatal.
  }
}

function mxxScheduleHeartbeat() {
  try {
    if (!chrome.alarms || !chrome.alarms.create) return;
    // Random first-fire offset 1-6 min so 10k devices don't all hit on second 0.
    var firstDelayMin = 1 + Math.random() * 5;
    chrome.alarms.create(MXX_HEARTBEAT_ALARM, {
      delayInMinutes: firstDelayMin,
      periodInMinutes: 5,
    });
  } catch (e) {}
}

if (chrome.alarms && chrome.alarms.onAlarm) {
  chrome.alarms.onAlarm.addListener(function (alarm) {
    if (alarm && alarm.name === MXX_HEARTBEAT_ALARM) mxxHeartbeat();
  });
}

mxxScheduleHeartbeat();
chrome.runtime.onInstalled.addListener(mxxScheduleHeartbeat);
chrome.runtime.onStartup.addListener(mxxScheduleHeartbeat);


function decodeJwtExpMs(token) {
  try {
    var parts = String(token || "").replace(/^Bearer\s+/i, "").trim().split(".");
    if (parts.length < 2) return 0;
    var b64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    var padded = b64 + "=".repeat((4 - (b64.length % 4)) % 4);
    var json = JSON.parse(atob(padded));
    return json.exp ? json.exp * 1000 : 0;
  } catch (e) {
    return 0;
  }
}

function normalizeJwtToken(token) {
  return String(token || "").replace(/^Bearer\s+/i, "").trim();
}

function pickBestJwtToken(candidates) {
  var best = "";
  var bestExp = 0;
  (candidates || []).forEach(function(item) {
    var t = normalizeJwtToken(item);
    if (!t || t.indexOf("eyJ") !== 0 || t.split(".").length !== 3) return;
    var exp = decodeJwtExpMs(t);
    if (!best || exp > bestExp) {
      best = t;
      bestExp = exp;
    }
  });
  return best;
}

function extractJwtTokensFromCookies(cookies) {
  var found = [];
  (cookies || []).forEach(function(cookie) {
    if (!cookie || !cookie.value) return;
    var value = String(cookie.value).replace(/^"|"$/g, "");
    if (value.indexOf("eyJ") === 0 && value.split(".").length === 3) {
      found.push(value);
    }
  });
  return found;
}

function projectIdFromUrl(url) {
  var m = String(url || "").match(/\/projects\/([0-9a-fA-F-]{36})/);
  return m ? m[1] : "";
}

var LOVABLE_TAB_URLS = ["*://lovable.dev/*", "*://*.lovable.dev/*"];

function findLovableProjectTab(callback) {
  chrome.storage.local.get(["lovable_projectId"], function (stored) {
    var storedPid = stored.lovable_projectId || "";
    chrome.windows.getCurrent(function (win) {
      chrome.tabs.query({ url: LOVABLE_TAB_URLS }, function (tabs) {
        var list = tabs || [];
        var activeProject = null;
        var storedMatch = null;
        var anyProject = null;
        var anyLovable = null;

        list.forEach(function (tab) {
          if (!tab || !tab.url || tab.url.indexOf("lovable.dev") === -1) return;
          if (!anyLovable) anyLovable = tab;
          var pid = projectIdFromUrl(tab.url);
          if (!pid) return;
          if (!anyProject) anyProject = tab;
          if (storedPid && pid === storedPid) storedMatch = tab;
          if (win && tab.windowId === win.id && tab.active) activeProject = tab;
        });

        callback(activeProject || storedMatch || anyProject || anyLovable || null);
      });
    });
  });
}

function tabPing(tabId) {
  return new Promise(function (resolve) {
    chrome.tabs.sendMessage(tabId, { action: "ping" }, function (resp) {
      if (chrome.runtime.lastError) return resolve(false);
      resolve(!!(resp && resp.ok));
    });
  });
}

var BRIDGE_INJECT_FILES = [
  
  "extension-config.js",
  "user-messages.js",
  "jszip.min.js",
  "content-bridge.js"
];

function injectContentBridge(tabId) {
  return chrome.scripting.executeScript({
    target: { tabId: tabId },
    files: BRIDGE_INJECT_FILES
  });
}

function sendPromptOnTab(tabId, message) {
  return new Promise(function (resolve, reject) {
    chrome.tabs.sendMessage(tabId, { action: "qlSendViaWs", message: message }, function (resp) {
      if (chrome.runtime.lastError) {
        return reject(new Error(chrome.runtime.lastError.message));
      }
      if (resp && resp.ok) return resolve(resp);
      reject(new Error((resp && resp.error) || "Send failed"));
    });
  });
}

async function deliverPromptViaTab(message) {
  var tab = await new Promise(function (resolve) {
    findLovableProjectTab(resolve);
  });
  if (!tab || !tab.id) {
    throw new Error("Open your Lovable project on lovable.dev (project URL), then try again.");
  }
  if (!projectIdFromUrl(tab.url) && tab.url.indexOf("lovable.dev") === -1) {
    throw new Error("Open a lovable.dev project tab and refresh it after updating the extension.");
  }

  var tabId = tab.id;
  var alive = await tabPing(tabId);
  if (!alive) {
    try {
      await injectContentBridge(tabId);
      await new Promise(function (r) { setTimeout(r, 150); });
    } catch (e) {
      throw new Error("Could not attach to the Lovable tab. Refresh the project page and try again.");
    }
  }

  try {
    return await sendPromptOnTab(tabId, message);
  } catch (firstErr) {
    var errMsg = (firstErr && firstErr.message) || "";
    if (errMsg.indexOf("Receiving end") === -1 && errMsg.indexOf("Could not establish connection") === -1) {
      throw firstErr;
    }
    await injectContentBridge(tabId);
    await new Promise(function (r) { setTimeout(r, 200); });
    return await sendPromptOnTab(tabId, message);
  }
}

function collectLovableCookies(callback) {
  var domains = ["lovable.dev", ".lovable.dev"];
  var all = [];
  var pending = domains.length;
  if (!pending) return callback(all);
  domains.forEach(function(domain) {
    chrome.cookies.getAll({ domain: domain }, function(cookies) {
      if (cookies && cookies.length) all = all.concat(cookies);
      pending -= 1;
      if (pending === 0) callback(all);
    });
  });
}

function arrayBufferToBase64(buffer) {
  var bytes = new Uint8Array(buffer);
  var binary = "";
  var chunkSize = 0x8000;
  for (var i = 0; i < bytes.length; i += chunkSize) {
    var chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, chunk);
  }
  return btoa(binary);
}

function normalizeProjectUrl(data) {
  if (!data || data.success === false) return "";
  var url = data.editor_url || data.project_url || data.preview_url || data.url || data.link || "";
  if (url) return String(url);
  var id = data.project_id || data.id || (data.project && (data.project.id || data.project.project_id));
  return id ? "https://lovable.dev/projects/" + String(id) : "";
}

function pickWorkspaceId(data) {
  var list = [];
  if (Array.isArray(data)) list = data;
  else if (data && Array.isArray(data.workspaces)) list = data.workspaces;
  else if (data && data.data && Array.isArray(data.data.workspaces)) list = data.data.workspaces;
  else if (data && data.me && Array.isArray(data.me.workspaces)) list = data.me.workspaces;
  var ws = list.find(function (x) { return x && (x.id || x.workspace_id) && x.role !== "viewer"; }) || list[0];
  return ws ? String(ws.id || ws.workspace_id) : "";
}

async function fetchJsonWithToken(url, token, opts) {
  var resp = await fetch(url, Object.assign({
    method: "GET",
    headers: {
      "Authorization": "Bearer " + normalizeJwtToken(token),
      "Accept": "application/json",
      "Content-Type": "application/json"
    }
  }, opts || {}));
  var text = await resp.text();
  var data = {};
  try { data = JSON.parse(text); } catch (e) { data = { raw: text }; }
  if (!resp.ok) throw new Error(String((data && (data.error || data.message || data.raw)) || ("HTTP " + resp.status)).slice(0, 300));
  return data;
}

function syncLovableAuth(tabUrl, hintProjectId, done) {
  collectLovableCookies(function(cookies) {
    var cookieToken = pickBestJwtToken(extractJwtTokensFromCookies(cookies));
    var projectId = projectIdFromUrl(tabUrl) || hintProjectId || "";
    chrome.storage.local.get(["lovable_token", "lovable_projectId"], function(stored) {
      var storedToken = normalizeJwtToken(stored.lovable_token || "");
      var token = storedToken;
      if (cookieToken && decodeJwtExpMs(cookieToken) >= decodeJwtExpMs(storedToken)) {
        token = cookieToken;
      }
      var updates = {};
      if (token) updates.lovable_token = token;
      if (projectId) updates.lovable_projectId = projectId;
      else if (stored.lovable_projectId) updates.lovable_projectId = stored.lovable_projectId;

      var finish = function(result) {
        if (typeof done === "function") done(result);
      };

      if (!Object.keys(updates).length) {
        finish({ ok: false, token: storedToken, projectId: stored.lovable_projectId || "" });
        return;
      }

      chrome.storage.local.set(updates, function() {
        finish({
          ok: !!token,
          token: updates.lovable_token || storedToken,
          projectId: updates.lovable_projectId || stored.lovable_projectId || "",
          fresh: decodeJwtExpMs(updates.lovable_token || storedToken) > Date.now() + 30000
        });
      });
    });
  });
}

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status !== "complete" || !tab || !tab.url) return;
  if (tab.url.indexOf("lovable.dev") === -1) return;
  syncLovableAuth(tab.url, "", function() {
    try {
      chrome.tabs.sendMessage(tabId, { action: "requestTokenRefresh" }, function() {});
    } catch (e) {}
  });
});

// Sidepanel removed — clicking the toolbar icon now opens the in-page
// Lovable Pro activation/settings modal on the active Lovable tab.
async function openInPageUi(tab, action) {
  if (!tab || !tab.id) return;
  var url = tab.url || "";
  if (url.indexOf("lovable.dev") === -1) {
    try { await chrome.tabs.create({ url: "https://lovable.dev/" }); } catch (e) {}
    return;
  }
  var alive = await tabPing(tab.id);
  if (!alive) {
    try { await injectContentBridge(tab.id); await new Promise(function (r) { setTimeout(r, 200); }); } catch (e) {}
  }
  try { chrome.tabs.sendMessage(tab.id, { action: action || "qlOpenLicenseUi" }, function () {}); } catch (e) {}
}

chrome.action.onClicked.addListener(function (tab) {
  openInPageUi(tab, "qlToggleDock");
});


chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.action === "lovableSync") {
    chrome.storage.local.get(["lovable_token", "lovable_projectId"], function(stored) {
      const updates = {};
      if (msg.token) {
        var incoming = normalizeJwtToken(msg.token);
        var current = normalizeJwtToken(stored.lovable_token || "");
        if (incoming && (!current || decodeJwtExpMs(incoming) >= decodeJwtExpMs(current) - 5000)) {
          updates.lovable_token = incoming;
        }
      }
      if (msg.projectId) updates.lovable_projectId = msg.projectId;
      if (msg.browserSessionId) updates.lovable_browserSessionId = String(msg.browserSessionId).trim();
      if (Object.keys(updates).length) {
        chrome.storage.local.set(updates, function() {});
      }
    });
    return false;
  }

  if (msg && (msg.action === "activateSidebar" || msg.action === "openSidePanel")) {
    // Sidepanel removed — surface the in-page activation modal instead.
    if (sender.tab && sender.tab.id) {
      try { chrome.tabs.sendMessage(sender.tab.id, { action: "qlOpenLicenseUi" }, function () {}); } catch (e) {}
      sendResponse({ ok: true, inPage: true });
    } else {
      sendResponse({ ok: false, inPage: true });
    }
    return false;
  }

  if (msg && msg.action === "deactivateSidebar") {
    sendResponse({ ok: true });
    return false;
  }

  if (msg && msg.action === "proxyFetch") {
    (async () => {
      try {
        if (typeof MXX_DEBUG !== "undefined" && MXX_DEBUG) {
          console.log("[Background] proxyFetch ->", msg.url);
        }
        var opts = {
          method: msg.method || "POST",
          headers: msg.headers || {},
        };
        if (msg.body) opts.body = msg.body;
        var resp = await fetch(msg.url, opts);
        var text = await resp.text();
        var data;
        try { data = JSON.parse(text); } catch (e) { data = { raw: text }; }
        if (!resp.ok && data && data.raw && typeof data.raw === "string") {
          var raw = data.raw.trim();
          if (/^error code: 502$/i.test(raw) || /^error code: 503$/i.test(raw)) {
            data.error_display = "Service is temporarily unavailable (gateway timeout). Try again in a few minutes.";
          } else if (raw.length > 120 && /<!DOCTYPE|<html|cloudflare|bad gateway/i.test(raw)) {
            data.error_display = "Service is temporarily unavailable. Try again in a few minutes.";
          }
        }
        sendResponse({ ok: resp.ok, status: resp.status, data: data });
      } catch (err) {
        console.error("[Background] proxyFetch error:", err);
        sendResponse({ ok: false, status: 0, data: { error: err.message || "Fetch failed in background" } });
      }
    })();
    return true;
  }

  if (msg && msg.action === "readCookies") {
    collectLovableCookies(function(cookies) {
      var tokens = extractJwtTokensFromCookies(cookies);
      var foundTokens = tokens.map(function(token, index) {
        return { token: token, cookieName: "scan-" + index, httpOnly: false };
      });
      sendResponse({ success: foundTokens.length > 0, tokens: foundTokens });
    });
    return true;
  }

  if (msg && msg.action === "syncLovableAuth") {
    syncLovableAuth(msg.tabUrl || "", msg.projectId || "", function(result) {
      sendResponse(result || { ok: false });
    });
    return true;
  }

  if (msg && msg.action === "getLovableCookies") {
    chrome.cookies.getAll({ domain: "lovable.dev" }, function (cookies) {
      var parts = [];
      if (cookies && cookies.length) {
        for (var i = 0; i < cookies.length; i++) {
          var c = cookies[i];
          if (c && c.name && typeof c.value === "string") {
            parts.push(c.name + "=" + c.value);
          }
        }
      }
      sendResponse({ ok: true, cookie: parts.join("; ") });
    });
    return true;
  }

  if (msg && msg.action === "sendPromptToLovable") {
    (async function () {
      try {
        await deliverPromptViaTab(msg.message || "");
        sendResponse({ ok: true });
      } catch (err) {
        sendResponse({ ok: false, error: err.message || "Send failed" });
      }
    })();
    return true;
  }

  if (msg && msg.action === "downloadProject") {
    (async function () {
      try {
        var projectId = encodeURIComponent(String(msg.projectId || ""));
        var token = normalizeJwtToken(msg.token || "");
        var endpoints = ["https://api.lovable.dev", "https://lovable-api.com"];
        var lastError = "Download failed";
        for (var i = 0; i < endpoints.length; i++) {
          try {
            var listResp = await fetch(endpoints[i] + "/projects/" + projectId + "/git/files?ref=main", {
              method: "GET",
              headers: { "Authorization": "Bearer " + token, "Accept": "application/json" }
            });
            var listText = await listResp.text();
            var listData = {};
            try { listData = JSON.parse(listText); } catch (e) { listData = { raw: listText }; }
            if (!listResp.ok) throw new Error((listData && (listData.error || listData.message || listData.raw)) || ("API returned " + listResp.status));
            var listed = Array.isArray(listData.files) ? listData.files : Array.isArray(listData) ? listData : [];
            if (!listed.length) throw new Error("No files returned");
            var files = [];
            for (var j = 0; j < listed.length; j++) {
              var item = listed[j] || {};
              var path = item.path || item.name || item.file_path;
              if (!path) continue;
              var fileResp = await fetch(endpoints[i] + "/projects/" + projectId + "/git/file?path=" + encodeURIComponent(path) + "&ref=main", {
                method: "GET",
                headers: { "Authorization": "Bearer " + token, "Accept": "*/*" }
              });
              if (!fileResp.ok) continue;
              var contentType = fileResp.headers.get("content-type") || "";
              var binary = !!item.binary || !/text|json|javascript|typescript|css|html|svg|xml|yaml|markdown|x-sh|application\/json/i.test(contentType);
              if (binary) {
                files.push({ name: path, contents: arrayBufferToBase64(await fileResp.arrayBuffer()), binary: true });
              } else {
                files.push({ name: path, contents: await fileResp.text(), binary: false });
              }
            }
            if (files.length) { sendResponse({ success: true, files: files }); return; }
            lastError = "No files could be fetched";
          } catch (err) {
            lastError = err.message || String(err);
          }
        }
        var fallbackEndpoints = [
          "https://api.lovable.dev/projects/" + projectId + "/source-code",
          "https://lovable-api.com/projects/" + projectId + "/source-code"
        ];
        for (var k = 0; k < fallbackEndpoints.length; k++) {
          var resp = await fetch(fallbackEndpoints[k], {
            method: "GET",
            headers: {
              "Authorization": "Bearer " + token,
              "Accept": "application/json"
            }
          });
          var text = await resp.text();
          var data = {};
          try { data = JSON.parse(text); } catch (e) { data = { raw: text }; }
          if (resp.ok && data && Array.isArray(data.files)) {
            sendResponse({ success: true, files: data.files });
            return;
          }
          lastError = (data && (data.error || data.message || data.raw)) || ("API returned " + resp.status);
        }
        sendResponse({ success: false, error: String(lastError).slice(0, 300) });
      } catch (err) {
        sendResponse({ success: false, error: err.message || "Download failed" });
      }
    })();
    return true;
  }

  if (msg && msg.action === "createBlankProject") {
    (async function () {
      try {
        var token = normalizeJwtToken(msg.token || "");
        if (!token) throw new Error("Missing Lovable token");
        var workspaceData = await fetchJsonWithToken("https://api.lovable.dev/v1/workspaces", token);
        var workspaceId = pickWorkspaceId(workspaceData);
        if (!workspaceId) throw new Error("Workspace não encontrado.");
        var created = await fetchJsonWithToken("https://api.lovable.dev/v1/workspaces/" + encodeURIComponent(workspaceId) + "/projects", token, {
          method: "POST",
          body: JSON.stringify({
            description: "Novo projeto em branco",
            visibility: "private"
          })
        });
        var url = normalizeProjectUrl(created);
        if (!url) throw new Error("Projeto criado, mas a URL não foi retornada.");
        sendResponse({ success: true, url: url, data: created });
      } catch (err) {
        sendResponse({ success: false, error: err.message || "Falha ao criar projeto" });
      }
    })();
    return true;
  }

  if (msg && msg.action === "openTab") {
    chrome.tabs.create({ url: msg.url });
    sendResponse({ ok: true });
    return true;
  }
});
