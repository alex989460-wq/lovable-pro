DROP FUNCTION IF EXISTS public.validate_license_public(text, text, boolean);
DROP FUNCTION IF EXISTS public.validate_license_public(text, text);