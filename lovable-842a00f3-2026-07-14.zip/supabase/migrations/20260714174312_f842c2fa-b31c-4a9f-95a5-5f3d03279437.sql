CREATE TABLE IF NOT EXISTS public.license_validation_index (
  key_hash text PRIMARY KEY,
  license_key text NOT NULL,
  user_name text,
  status text NOT NULL DEFAULT 'active',
  active boolean NOT NULL DEFAULT true,
  lifetime boolean NOT NULL DEFAULT false,
  activated_at timestamp with time zone,
  issued_at timestamp with time zone,
  expires_at timestamp with time zone,
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  current_session_id uuid,
  current_device_id text,
  last_seen_at timestamp with time zone
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.license_validation_index TO service_role;

ALTER TABLE public.license_validation_index ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.licenses ADD COLUMN IF NOT EXISTS current_session_id uuid;
ALTER TABLE public.licenses ADD COLUMN IF NOT EXISTS current_device_id text;
ALTER TABLE public.licenses ADD COLUMN IF NOT EXISTS last_seen_at timestamp with time zone;
ALTER TABLE public.licenses ADD COLUMN IF NOT EXISTS activated_at timestamp with time zone;

CREATE OR REPLACE FUNCTION public.sync_license_validation_index()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE
  old_hash text;
  new_hash text;
  license_lifetime boolean;
  license_active boolean;
BEGIN
  IF TG_OP = 'DELETE' THEN
    old_hash := encode(extensions.digest(upper(trim(OLD.key)), 'sha256'), 'hex');
    DELETE FROM public.license_validation_index WHERE key_hash = old_hash;
    RETURN OLD;
  END IF;

  new_hash := encode(extensions.digest(upper(trim(NEW.key)), 'sha256'), 'hex');
  license_lifetime := NEW.duration_type::text = 'lifetime';
  license_active := coalesce(NEW.is_active, true);

  IF TG_OP = 'UPDATE' AND OLD.key IS DISTINCT FROM NEW.key THEN
    old_hash := encode(extensions.digest(upper(trim(OLD.key)), 'sha256'), 'hex');
    DELETE FROM public.license_validation_index WHERE key_hash = old_hash;
  END IF;

  INSERT INTO public.license_validation_index (
    key_hash,
    license_key,
    user_name,
    status,
    active,
    lifetime,
    activated_at,
    issued_at,
    expires_at,
    updated_at,
    current_session_id,
    current_device_id,
    last_seen_at
  ) VALUES (
    new_hash,
    upper(trim(NEW.key)),
    coalesce(nullif(NEW.user_name, ''), 'Lovable Pro User'),
    CASE WHEN license_active THEN 'active' ELSE 'inactive' END,
    license_active,
    license_lifetime,
    coalesce(NEW.activated_at, NEW.created_at),
    NEW.created_at,
    NEW.expires_at,
    now(),
    NEW.current_session_id,
    NEW.current_device_id,
    NEW.last_seen_at
  )
  ON CONFLICT (key_hash) DO UPDATE SET
    license_key = EXCLUDED.license_key,
    user_name = EXCLUDED.user_name,
    status = EXCLUDED.status,
    active = EXCLUDED.active,
    lifetime = EXCLUDED.lifetime,
    activated_at = EXCLUDED.activated_at,
    issued_at = EXCLUDED.issued_at,
    expires_at = EXCLUDED.expires_at,
    current_session_id = EXCLUDED.current_session_id,
    current_device_id = EXCLUDED.current_device_id,
    last_seen_at = EXCLUDED.last_seen_at,
    updated_at = now();

  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS sync_license_validation_index_trigger ON public.licenses;
CREATE TRIGGER sync_license_validation_index_trigger
AFTER INSERT OR UPDATE OR DELETE ON public.licenses
FOR EACH ROW EXECUTE FUNCTION public.sync_license_validation_index();

INSERT INTO public.license_validation_index (
  key_hash,
  license_key,
  user_name,
  status,
  active,
  lifetime,
  activated_at,
  issued_at,
  expires_at,
  updated_at,
  current_session_id,
  current_device_id,
  last_seen_at
)
SELECT
  encode(extensions.digest(upper(trim(key)), 'sha256'), 'hex'),
  upper(trim(key)),
  coalesce(nullif(user_name, ''), 'Lovable Pro User'),
  CASE WHEN coalesce(is_active, true) THEN 'active' ELSE 'inactive' END,
  coalesce(is_active, true),
  duration_type::text = 'lifetime',
  coalesce(activated_at, created_at),
  created_at,
  expires_at,
  now(),
  current_session_id,
  current_device_id,
  last_seen_at
FROM public.licenses
ON CONFLICT (key_hash) DO UPDATE SET
  license_key = EXCLUDED.license_key,
  user_name = EXCLUDED.user_name,
  status = EXCLUDED.status,
  active = EXCLUDED.active,
  lifetime = EXCLUDED.lifetime,
  activated_at = EXCLUDED.activated_at,
  issued_at = EXCLUDED.issued_at,
  expires_at = EXCLUDED.expires_at,
  current_session_id = EXCLUDED.current_session_id,
  current_device_id = EXCLUDED.current_device_id,
  last_seen_at = EXCLUDED.last_seen_at,
  updated_at = now();

CREATE OR REPLACE FUNCTION public.validate_license_public(_key text, _device_id text DEFAULT NULL::text, _heartbeat boolean DEFAULT false)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE
  normalized_key text := upper(trim(coalesce(_key, '')));
  normalized_device text := nullif(trim(coalesce(_device_id, '')), '');
  lookup_hash text;
  license_row public.license_validation_index%rowtype;
  new_session uuid;
BEGIN
  IF normalized_key = '' THEN
    RETURN jsonb_build_object('valid', false, 'reason', 'invalid_input');
  END IF;

  lookup_hash := encode(extensions.digest(normalized_key, 'sha256'), 'hex');

  SELECT * INTO license_row
  FROM public.license_validation_index
  WHERE key_hash = lookup_hash
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('valid', false, 'reason', 'invalid_key');
  END IF;

  IF NOT coalesce(license_row.active, false) OR coalesce(license_row.status, '') <> 'active' THEN
    RETURN jsonb_build_object('valid', false, 'reason', 'inactive');
  END IF;

  IF NOT coalesce(license_row.lifetime, false)
     AND license_row.expires_at IS NOT NULL
     AND license_row.expires_at < now() THEN
    RETURN jsonb_build_object('valid', false, 'reason', 'expired');
  END IF;

  IF _heartbeat
     AND normalized_device IS NOT NULL
     AND license_row.current_device_id IS NOT NULL
     AND license_row.current_device_id <> normalized_device THEN
    RETURN jsonb_build_object('valid', false, 'reason', 'device_mismatch');
  END IF;

  IF normalized_device IS NOT NULL AND (
      license_row.current_device_id IS NULL
      OR license_row.current_device_id <> normalized_device
      OR license_row.current_session_id IS NULL
    ) THEN
    new_session := gen_random_uuid();
    UPDATE public.licenses
      SET current_session_id = new_session,
          current_device_id = normalized_device,
          last_seen_at = now(),
          activated_at = coalesce(activated_at, now())
      WHERE upper(trim(key)) = normalized_key;
  ELSE
    new_session := license_row.current_session_id;
    IF normalized_device IS NOT NULL THEN
      UPDATE public.licenses
        SET last_seen_at = now()
        WHERE upper(trim(key)) = normalized_key;
    END IF;
  END IF;

  RETURN jsonb_build_object(
    'valid', true,
    'key', normalized_key,
    'user_name', coalesce(nullif(license_row.user_name, ''), 'Lovable Pro User'),
    'activated_at', coalesce(license_row.activated_at, license_row.issued_at),
    'issued_at', license_row.issued_at,
    'expires_at', license_row.expires_at,
    'lifetime', coalesce(license_row.lifetime, false),
    'status', 'active',
    'session_id', new_session,
    'device_id', normalized_device
  );
EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('valid', false, 'reason', SQLERRM);
END;
$function$;

CREATE OR REPLACE FUNCTION public.heartbeat_license(_key text, _session_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE
  normalized_key text := upper(trim(coalesce(_key, '')));
  lookup_hash text;
  license_row public.license_validation_index%rowtype;
BEGIN
  IF normalized_key = '' OR _session_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_input');
  END IF;

  lookup_hash := encode(extensions.digest(normalized_key, 'sha256'), 'hex');

  SELECT * INTO license_row
  FROM public.license_validation_index
  WHERE key_hash = lookup_hash
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_key');
  END IF;

  IF NOT coalesce(license_row.active, false) OR coalesce(license_row.status, '') <> 'active' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'inactive');
  END IF;

  IF NOT coalesce(license_row.lifetime, false)
     AND license_row.expires_at IS NOT NULL
     AND license_row.expires_at < now() THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'expired');
  END IF;

  IF license_row.current_session_id IS DISTINCT FROM _session_id THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'session_replaced');
  END IF;

  UPDATE public.licenses
    SET last_seen_at = now()
    WHERE upper(trim(key)) = normalized_key;

  RETURN jsonb_build_object('ok', true);
EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'reason', SQLERRM);
END;
$function$;