GRANT SELECT ON public.licenses TO anon;
GRANT SELECT ON public.licenses TO authenticated;
GRANT ALL ON public.licenses TO service_role;

CREATE OR REPLACE FUNCTION public.validate_license_public(
  _key text,
  _device_id text DEFAULT NULL,
  _heartbeat boolean DEFAULT false
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _license public.licenses%ROWTYPE;
  _normalized_key text;
  _activated_at timestamptz;
  _expires_at timestamptz;
  _lifetime boolean;
  _session_id uuid;
BEGIN
  _normalized_key := upper(trim(coalesce(_key, '')));

  IF _normalized_key = '' OR length(_normalized_key) > 64 THEN
    RETURN jsonb_build_object('valid', false, 'reason', 'invalid_input');
  END IF;

  SELECT *
    INTO _license
  FROM public.licenses
  WHERE key = _normalized_key
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('valid', false, 'reason', 'not_found');
  END IF;

  IF _license.is_active IS FALSE THEN
    RETURN jsonb_build_object('valid', false, 'reason', 'inactive');
  END IF;

  _lifetime := _license.duration_type::text = 'lifetime';
  _activated_at := coalesce(_license.activated_at, _license.created_at, now());

  IF _lifetime THEN
    _expires_at := NULL;
  ELSE
    _expires_at := _license.expires_at;
    IF _expires_at IS NULL AND _license.duration_type::text = 'hours' AND coalesce(_license.duration_value, 0) > 0 THEN
      _expires_at := _activated_at + make_interval(hours => _license.duration_value);
    ELSIF _expires_at IS NULL AND _license.duration_type::text = 'days' AND coalesce(_license.duration_value, 0) > 0 THEN
      _expires_at := _activated_at + make_interval(days => _license.duration_value);
    END IF;
  END IF;

  IF NOT _lifetime AND _expires_at IS NOT NULL AND _expires_at < now() THEN
    RETURN jsonb_build_object('valid', false, 'reason', 'expired');
  END IF;

  IF coalesce(_heartbeat, false)
     AND nullif(trim(coalesce(_device_id, '')), '') IS NOT NULL
     AND _license.current_device_id IS NOT NULL
     AND _license.current_device_id <> trim(_device_id) THEN
    RETURN jsonb_build_object('valid', false, 'reason', 'device_mismatch');
  END IF;

  _session_id := coalesce(_license.current_session_id, gen_random_uuid());

  IF nullif(trim(coalesce(_device_id, '')), '') IS NOT NULL THEN
    UPDATE public.licenses
    SET current_device_id = trim(_device_id),
        current_session_id = _session_id,
        activated_at = coalesce(activated_at, now()),
        expires_at = _expires_at,
        last_seen_at = now()
    WHERE id = _license.id;
  END IF;

  RETURN jsonb_build_object(
    'valid', true,
    'key', _normalized_key,
    'user_name', coalesce(nullif(trim(_license.user_name), ''), 'Lovable Pro User'),
    'activated_at', coalesce(_license.activated_at, now()),
    'issued_at', _license.created_at,
    'expires_at', _expires_at,
    'duration_type', _license.duration_type::text,
    'duration_value', _license.duration_value,
    'lifetime', _lifetime,
    'status', 'active',
    'session_id', _session_id,
    'device_id', nullif(trim(coalesce(_device_id, '')), ''),
    'support', jsonb_build_object(
      'whatsapp_url', NULL,
      'contact_url', NULL,
      'contact_label', NULL
    )
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.validate_license_public(text, text, boolean) TO anon;
GRANT EXECUTE ON FUNCTION public.validate_license_public(text, text, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.validate_license_public(text, text, boolean) TO service_role;