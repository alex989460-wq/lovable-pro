DROP POLICY IF EXISTS "Service role can manage license validation index" ON public.license_validation_index;
CREATE POLICY "Service role can manage license validation index"
ON public.license_validation_index
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);