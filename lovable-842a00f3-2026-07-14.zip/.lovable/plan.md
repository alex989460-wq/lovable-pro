## Objetivo

Fazer a extensão validar licenças contra o **seu** backend (este projeto TanStack + Supabase) em vez de `unlimitedprompts.lovable.app`.

## O que será implementado

### 1. Banco de dados (Supabase)
Tabela `licenses`:
- `key` (text, único) — a chave, ex: `LVBL-XXXX-XXXX-XXXX-XXXX`
- `status` (text) — `active` | `revoked` | `paused` | `expired`
- `activated_at`, `expires_at` (timestamptz, nulos)
- `device_id` (text, nulo) — dispositivo em que foi ativada (lock opcional)
- `notes` (text)
- `created_at`

Sem RLS pública (leitura só via server function). GRANT apenas para `service_role`.

### 2. Endpoint público `POST /api/public/validate-license`
Rota TanStack em `src/routes/api/public/validate-license.ts`:
- Recebe `{ key, device_id, manifest_name, manifest_version }`
- Consulta a tabela via `supabaseAdmin`
- Regras:
  - chave não existe → `{ valid:false, reason:"not_found" }`
  - status `revoked/paused/expired` → devolve esse motivo
  - `expires_at < now()` → marca `expired` e devolve `expired`
  - primeiro uso: grava `device_id` e `activated_at`
  - uso posterior de outro `device_id` → `{ valid:false, reason:"device_mismatch" }` (pode ser desativado se você quiser multi-device)
  - válida → `{ valid:true, key, activated_at, expires_at, support:{ contact_url, whatsapp_url } }`
- CORS liberado (a extensão chama de outra origem)
- **Sem assinatura Ed25519** — a extensão só verifica assinatura se `window.MxxTamperGuard` existir; como não existe no bundle, o campo é ignorado com segurança.

### 3. Ajuste mínimo na extensão
Só a URL muda (2 arquivos):
- `extension/license-gate.js` linha 8
- `extension/background.js` linha 23

Nova URL: `https://project-serene-moment.lovable.app/api/public/validate-license` (URL publicada deste projeto).

Rebuild do ZIP em `public/unlimited-lovable-extension.zip`.

### 4. Como criar/gerenciar chaves
Sem UI de admin nesta primeira versão. Você cria/edita chaves direto no **SQL Editor** do Supabase:

```sql
insert into public.licenses (key, status, expires_at)
values ('LVBL-CTVA-G3E9-Y5HC-NXY3', 'active', now() + interval '1 year');
```

Se depois quiser um painel `/admin/licenses` protegido, é um segundo passo.

## Detalhes técnicos

- Endpoint sob `/api/public/*` (bypassa auth do site publicado; a extensão é um cliente externo).
- Valida input com Zod (`key` string ≤64, `device_id` string ≤128).
- `supabaseAdmin` importado dinamicamente dentro do handler (`await import(...)`).
- Rate limiting: não incluso nesta iteração — se abusarem, adicionamos depois.
- Extensão continua funcionando offline pelo cache de 5 min já existente em `license-gate.js`.

## O que NÃO está incluído

- Painel visual de admin para criar/revogar chaves (fica para depois).
- Assinatura Ed25519 do payload (o cliente não exige; só valida se o guard existir).
- Métricas de uso por chave.
