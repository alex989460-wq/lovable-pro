import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With, Accept, Origin",
  "Access-Control-Max-Age": "86400",
};

const bodySchema = z.object({
  key: z.string().optional(),
  license_key: z.string().optional(),
  event_type: z.string().optional(),
  type: z.string().optional(),
  device_id: z.string().optional().nullable(),
  metadata: z.record(z.unknown()).optional().nullable(),
});

function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: corsHeaders });
}

export const Route = createFileRoute("/api/public/track-event")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders }),
      POST: async ({ request }) => {
        try {
          const parsed = bodySchema.parse(await request.json().catch(() => ({})));
          const key = (parsed.key || parsed.license_key || "").trim().toUpperCase();
          const eventType = (parsed.event_type || parsed.type || "event").trim().slice(0, 80);
          if (!key) return json({ ok: false, reason: "missing_key" }, 400);

          return json({ ok: true, key, event_type: eventType, device_id: parsed.device_id || null });
        } catch (error) {
          return json({ ok: false, reason: error instanceof Error ? error.message : "invalid_request" }, 400);
        }
      },
    },
  },
});