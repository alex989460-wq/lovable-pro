import { createFileRoute } from "@tanstack/react-router";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Requested-With, Accept, Origin, x-license-key, x-device-id, x-file-name",
  "Access-Control-Max-Age": "86400",
};

function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: corsHeaders });
}

async function validateLicense(key: string) {
  const { createClient } = await import("@supabase/supabase-js");
  const url = process.env.SUPABASE_URL!;
  const anon = (process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_PUBLISHABLE_KEY)!;
  const sb = createClient(url, anon, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (anon.startsWith("sb_") && h.get("Authorization") === `Bearer ${anon}`) h.delete("Authorization");
        h.set("apikey", anon);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
  const { data } = await sb
    .from("licenses")
    .select("key,is_active,expires_at,duration_type")
    .eq("key", key)
    .eq("is_active", true)
    .maybeSingle();
  if (!data) return false;
  if (data.duration_type !== "lifetime" && data.expires_at && new Date(data.expires_at).getTime() < Date.now()) {
    return false;
  }
  return true;
}

export const Route = createFileRoute("/api/public/upload-asset")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders }),
      POST: async ({ request }) => {
        try {
          const key = (request.headers.get("x-license-key") || "").trim().toUpperCase();
          if (!key) return json({ ok: false, reason: "missing_key" }, 401);
          if (!(await validateLicense(key))) return json({ ok: false, reason: "invalid_license" }, 403);

          const contentType = request.headers.get("content-type") || "application/octet-stream";
          const rawName = request.headers.get("x-file-name") || "upload";
          let fileName = "upload";
          try { fileName = decodeURIComponent(rawName); } catch { fileName = rawName; }
          fileName = fileName.replace(/[^\w.\-]+/g, "_").slice(0, 120) || "upload";

          const bytes = new Uint8Array(await request.arrayBuffer());
          if (bytes.byteLength === 0) return json({ ok: false, reason: "empty_body" }, 400);
          if (bytes.byteLength > 25 * 1024 * 1024) return json({ ok: false, reason: "file_too_large" }, 413);

          const fileId = crypto.randomUUID();
          const path = `${key}/${fileId}-${fileName}`;

          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          const { error: upErr } = await supabaseAdmin.storage
            .from("prompt-uploads")
            .upload(path, bytes, { contentType, upsert: false });
          if (upErr) return json({ ok: false, reason: upErr.message }, 500);

          const { data: signed, error: signErr } = await supabaseAdmin.storage
            .from("prompt-uploads")
            .createSignedUrl(path, 60 * 60 * 24 * 365);
          if (signErr || !signed?.signedUrl) return json({ ok: false, reason: "sign_failed" }, 500);

          return json({
            ok: true,
            file_id: fileId,
            file_name: fileName,
            public_url: signed.signedUrl,
          });
        } catch (error) {
          return json({ ok: false, reason: error instanceof Error ? error.message : "unknown_error" }, 500);
        }
      },
    },
  },
});
