import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With, Accept, Origin",
  "Access-Control-Max-Age": "86400",
};

const bodySchema = z.object({
  key: z.string().optional(),
  _key: z.string().optional(),
  session_id: z.string().uuid().optional(),
  _session_id: z.string().uuid().optional(),
});

function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: corsHeaders });
}

export const Route = createFileRoute("/api/public/heartbeat-license")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders }),
      POST: async ({ request }) => {
        try {
          const parsed = bodySchema.parse(await request.json().catch(() => ({})));
          const key = (parsed.key || parsed._key || "").trim().toUpperCase();
          const sessionId = parsed.session_id || parsed._session_id;
          if (!key || !sessionId) return json({ ok: false, reason: "missing_key_or_session" }, 400);

          return json({ ok: true, key, session_id: sessionId, checked_at: new Date().toISOString() });
        } catch (error) {
          return json({ ok: false, reason: error instanceof Error ? error.message : "invalid_request" }, 400);
        }
      },
    },
  },
});