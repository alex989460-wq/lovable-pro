import { createFileRoute } from '@tanstack/react-router';
import { createClient } from '@supabase/supabase-js';
import { z } from 'zod';
import type { Database } from '@/integrations/supabase/types';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Max-Age': '86400',
};

const BodySchema = z.object({
  key: z.string().trim().min(1).max(64),
  device_id: z.string().trim().max(200).optional().nullable(),
  heartbeat: z.boolean().optional(),
  manifest_name: z.string().max(200).optional().nullable(),
  manifest_version: z.string().max(50).optional().nullable(),
});

const SUPABASE_URL_FALLBACK = 'https://xmukfwtcbvujztmtdllu.supabase.co';

function isNewSupabaseApiKey(value: string): boolean {
  return value.startsWith('sb_publishable_') || value.startsWith('sb_secret_');
}

function createSupabaseFetch(supabaseKey: string): typeof fetch {
  return (input, init) => {
    const headers = new Headers(init?.headers);
    if (isNewSupabaseApiKey(supabaseKey) && headers.get('Authorization') === `Bearer ${supabaseKey}`) {
      headers.delete('Authorization');
    }
    headers.set('apikey', supabaseKey);
    return fetch(input, { ...init, headers });
  };
}

function createServerSupabase() {
  const supabaseKey =
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    process.env.SUPABASE_SECRET_KEY ||
    process.env.SUPABASE_SECRET_KEYS ||
    process.env.SUPABASE_PUBLISHABLE_KEY ||
    process.env.SUPABASE_ANON_KEY ||
    process.env.VITE_SUPABASE_PUBLISHABLE_KEY;

  if (!supabaseKey) {
    throw new Error('Supabase key is not configured for license validation.');
  }

  return createClient<Database>(
    process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || SUPABASE_URL_FALLBACK,
    supabaseKey,
    {
      global: { fetch: createSupabaseFetch(supabaseKey) },
      auth: {
        storage: undefined,
        persistSession: false,
        autoRefreshToken: false,
      },
    },
  );
}

function addDuration(baseIso: string | null | undefined, type: string | null | undefined, value: number | null | undefined) {
  if (!baseIso || !type || !value || value < 1) return null;
  const base = new Date(baseIso).getTime();
  if (!Number.isFinite(base)) return null;
  const ms = type === 'hours' ? value * 3_600_000 : type === 'days' ? value * 86_400_000 : 0;
  return ms ? new Date(base + ms).toISOString() : null;
}

export const Route = createFileRoute('/api/public/validate-license')({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      GET: async () => Response.json({ status: 'ok', message: 'Endpoint is active' }, { headers: CORS }),
      POST: async ({ request }) => {
        let raw: unknown;
        try {
          raw = await request.json();
        } catch (e) {
          return Response.json(
            { valid: false, reason: 'invalid_json', error: String(e) },
            { status: 200, headers: CORS },
          );
        }

        const parsed = BodySchema.safeParse(raw);
        if (!parsed.success) {
          return Response.json(
            { valid: false, reason: 'invalid_input', details: parsed.error.format() },
            { status: 200, headers: CORS },
          );
        }

        const normalizedKey = parsed.data.key.trim().toUpperCase();
        const deviceId = parsed.data.device_id?.trim() || null;
        const supabaseServer = createServerSupabase();
        const { data: license, error } = await supabaseServer
          .from('licenses')
          .select('key,user_name,created_at,activated_at,expires_at,duration_type,duration_value,is_active,current_device_id,current_session_id')
          .eq('key', normalizedKey)
          .maybeSingle();

        if (error) {
          return Response.json({ valid: false, reason: error.message }, { status: 200, headers: CORS });
        }
        if (!license) {
          return Response.json({ valid: false, reason: 'not_found' }, { status: 200, headers: CORS });
        }
        if (license.is_active === false) {
          return Response.json({ valid: false, reason: 'inactive' }, { status: 200, headers: CORS });
        }

        const lifetime = license.duration_type === 'lifetime';
        const activatedAt = license.activated_at || license.created_at || new Date().toISOString();
        const computedExpiresAt = lifetime
          ? null
          : license.expires_at || addDuration(activatedAt, license.duration_type, license.duration_value);

        if (!lifetime && computedExpiresAt && new Date(computedExpiresAt).getTime() < Date.now()) {
          return Response.json({ valid: false, reason: 'expired' }, { status: 200, headers: CORS });
        }

        if (
          parsed.data.heartbeat &&
          deviceId &&
          license.current_device_id &&
          license.current_device_id !== deviceId
        ) {
          return Response.json({ valid: false, reason: 'device_mismatch' }, { status: 200, headers: CORS });
        }

        const sessionId = license.current_session_id || crypto.randomUUID();

        return Response.json({
          valid: true,
          key: normalizedKey,
          user_name: license.user_name || 'Lovable Pro User',
          activated_at: activatedAt,
          issued_at: license.created_at,
          expires_at: computedExpiresAt,
          duration_type: license.duration_type,
          duration_value: license.duration_value,
          lifetime,
          status: 'active',
          session_id: sessionId,
          device_id: deviceId,
          support: {
            whatsapp_url: null,
            contact_url: null,
            contact_label: null,
          },
        }, {
          status: 200,
          headers: CORS,
        });
      },
    },
  },
});
