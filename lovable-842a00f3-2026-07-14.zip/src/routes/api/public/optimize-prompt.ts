import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With, Accept, Origin, x-license-key",
  "Access-Control-Max-Age": "86400",
};

function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: corsHeaders });
}

const bodySchema = z.object({
  prompt: z.string().max(8000).optional(),
  text: z.string().max(8000).optional(),
  input: z.string().max(8000).optional(),
});

// Optimização local — idêntica à mxxOptimizePromptLocal da extensão original.
// Não usa IA e não consome créditos.
function optimizeLocal(raw: string): string {
  let text = String(raw || "").trim();
  if (!text) return "";
  if (/^📨\s*Enviado por Lovable Pro/i.test(text)) {
    text = text.replace(/^📨\s*Enviado por Lovable Pro\s*/i, "").trim();
  }
  const compact = text.replace(/\s+/g, " ").trim();
  const isFix = /erro|corrigir|bug|falha|typescript|typeerror|exception|crash|não funciona|nao funciona/i.test(compact);
  const action = isFix
    ? "Corrija"
    : /crie|criar|construa|faça|faca|implemente/i.test(compact)
    ? "Crie"
    : "Implemente";
  return [
    `${action} no projeto Lovable a seguinte solicitação, mantendo todos os textos em português do Brasil:`,
    "",
    compact,
    "",
    "Requisitos:",
    "- Preserve o design e as funcionalidades existentes que não foram citadas.",
    "- Faça apenas as alterações necessárias para atender ao pedido.",
    "- Se houver erro, corrija a causa raiz sem substituir a solicitação do usuário por mensagens genéricas.",
    "- Garanta que a interface continue responsiva e sem quebras visuais.",
  ].join("\n");
}

export const Route = createFileRoute("/api/public/optimize-prompt")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders }),
      POST: async ({ request }) => {
        try {
          const parsed = bodySchema.parse(await request.json().catch(() => ({})));
          const input = (parsed.prompt || parsed.text || parsed.input || "").trim();
          if (!input) return json({ ok: false, reason: "missing_input" }, 400);

          const optimized = optimizeLocal(input);
          return json({
            ok: true,
            prompt: optimized,
            optimized_prompt: optimized,
            result: optimized,
          });
        } catch (error) {
          return json({ ok: false, reason: error instanceof Error ? error.message : "unknown_error" }, 500);
        }
      },
    },
  },
});
