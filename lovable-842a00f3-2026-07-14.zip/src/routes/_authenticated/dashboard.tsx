import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Shield, LogOut, Plus, Copy, Trash2, Download, Loader2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import extensionZipUrl from "@/assets/unlimited-lovable-extension.zip?url";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: Dashboard,
});

type License = {
  id: string;
  key: string;
  duration_type: "hours" | "days" | "lifetime";
  duration_value: number | null;
  expires_at: string | null;
  user_name: string | null;
  user_email: string | null;
  user_phone: string | null;
  is_active: boolean;
  created_at: string;
};

function randomKey() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const seg = () => Array.from({ length: 4 }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join("");
  return `LVBL-${seg()}-${seg()}-${seg()}-${seg()}`;
}

function Dashboard() {
  const navigate = useNavigate();
  const [licenses, setLicenses] = useState<License[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [userEmail, setUserEmail] = useState<string>("");

  // Form
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [durationType, setDurationType] = useState<"hours" | "days" | "lifetime">("days");
  const [durationValue, setDurationValue] = useState<number>(30);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      setUserEmail(u.user?.email ?? "");
      if (!u.user) return;
      const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", u.user.id);
      const admin = roles?.some((r) => r.role === "admin") ?? false;
      setIsAdmin(admin);
      if (admin) await loadLicenses();
      setLoading(false);
    })();
  }, []);

  async function loadLicenses() {
    const { data, error } = await supabase.from("licenses").select("*").order("created_at", { ascending: false });
    if (error) return toast.error(error.message);
    setLicenses((data ?? []) as License[]);
  }

  async function createLicense(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    const key = randomKey();
    let expires_at: string | null = null;
    if (durationType === "hours") expires_at = new Date(Date.now() + durationValue * 3600_000).toISOString();
    if (durationType === "days") expires_at = new Date(Date.now() + durationValue * 86400_000).toISOString();

    const { error } = await supabase.from("licenses").insert({
      key,
      duration_type: durationType,
      duration_value: durationType === "lifetime" ? null : durationValue,
      expires_at,
      user_name: name || null,
      user_email: email || null,
      user_phone: phone || null,
    });
    setCreating(false);
    if (error) return toast.error(error.message);
    toast.success(`License created: ${key}`);
    setName(""); setEmail(""); setPhone("");
    await loadLicenses();
  }

  async function toggleActive(lic: License) {
    const { error } = await supabase.from("licenses").update({ is_active: !lic.is_active }).eq("id", lic.id);
    if (error) return toast.error(error.message);
    await loadLicenses();
  }

  async function remove(id: string) {
    if (!confirm("Delete this license?")) return;
    const { error } = await supabase.from("licenses").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    await loadLicenses();
  }

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  function copy(text: string) {
    navigator.clipboard.writeText(text);
    toast.success("Copied");
  }

  async function downloadExtension() {
    const fileName = "unlimited-lovable-extension.zip";
    const paths = [extensionZipUrl, `/public/${fileName}`, `/${fileName}`];

    try {
      let response: Response | null = null;
      for (const path of paths) {
        const candidate = await fetch(path, { cache: "no-store" });
        if (candidate.ok) {
          response = candidate;
          break;
        }
      }

      if (!response) throw new Error("Não consegui encontrar o arquivo da extensão.");

      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = objectUrl;
      a.download = fileName;
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1_000);
      toast.success("Download da extensão iniciado.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Falha ao baixar a extensão.");
    }
  }

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>;
  }

  return (
    <div className="min-h-screen bg-[#fcfbf8]">
      <nav className="border-b bg-white/60 backdrop-blur sticky top-0 z-40">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary p-2 rounded-lg"><Shield className="w-5 h-5 text-white" /></div>
            <span className="font-bold">Admin Dashboard</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground hidden sm:inline">{userEmail}</span>
            <Button variant="outline" size="sm" onClick={downloadExtension}>
              <Download className="w-4 h-4 mr-2" /> Extension
            </Button>
            <Button variant="ghost" size="sm" onClick={signOut}>
              <LogOut className="w-4 h-4 mr-2" /> Sign out
            </Button>
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-8 space-y-8">
        {!isAdmin && (
          <Card className="border-amber-300 bg-amber-50">
            <CardHeader className="flex-row items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 mt-1" />
              <div>
                <CardTitle className="text-amber-900">You don't have admin access</CardTitle>
                <CardDescription className="text-amber-800">
                  Only <code className="font-mono">admin@admin.com</code> receives admin automatically on signup.
                  Sign up with that email or ask an admin to grant you the role.
                </CardDescription>
              </div>
            </CardHeader>
          </Card>
        )}

        {isAdmin && (
          <>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Plus className="w-5 h-5" /> Create License</CardTitle>
                <CardDescription>Generate a new license key for a customer.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={createLicense} className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Name</Label>
                    <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="John Doe" />
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="john@example.com" />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone</Label>
                    <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+55 ..." />
                  </div>
                  <div className="space-y-2">
                    <Label>Duration</Label>
                    <Select value={durationType} onValueChange={(v: "hours" | "days" | "lifetime") => setDurationType(v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hours">Hours</SelectItem>
                        <SelectItem value="days">Days</SelectItem>
                        <SelectItem value="lifetime">Lifetime</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {durationType !== "lifetime" && (
                    <div className="space-y-2">
                      <Label>Value</Label>
                      <Input type="number" min={1} value={durationValue} onChange={(e) => setDurationValue(Number(e.target.value))} />
                    </div>
                  )}
                  <div className="flex items-end">
                    <Button type="submit" className="w-full" disabled={creating}>
                      {creating && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                      Generate License
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Licenses ({licenses.length})</CardTitle>
                <CardDescription>All licenses issued from this dashboard.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Key</TableHead>
                        <TableHead>User</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead>Expires</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {licenses.length === 0 && (
                        <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No licenses yet</TableCell></TableRow>
                      )}
                      {licenses.map((l) => (
                        <TableRow key={l.id}>
                          <TableCell>
                            <button onClick={() => copy(l.key)} className="font-mono text-xs hover:text-primary flex items-center gap-1">
                              {l.key} <Copy className="w-3 h-3" />
                            </button>
                          </TableCell>
                          <TableCell className="text-sm">
                            <div>{l.user_name || "—"}</div>
                            <div className="text-xs text-muted-foreground">{l.user_email}</div>
                          </TableCell>
                          <TableCell className="text-sm">
                            {l.duration_type === "lifetime" ? "Lifetime" : `${l.duration_value} ${l.duration_type}`}
                          </TableCell>
                          <TableCell className="text-xs">
                            {l.expires_at ? new Date(l.expires_at).toLocaleString() : "Never"}
                          </TableCell>
                          <TableCell>
                            <Badge variant={l.is_active ? "default" : "secondary"}>
                              {l.is_active ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right space-x-2">
                            <Button size="sm" variant="outline" onClick={() => toggleActive(l)}>
                              {l.is_active ? "Disable" : "Enable"}
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => remove(l.id)}>
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </div>
  );
}
