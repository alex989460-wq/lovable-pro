import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Layout, Key, Settings, ExternalLink } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-[#fcfbf8]">
      {/* Navigation */}
      <nav className="border-b bg-white/50 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary p-2 rounded-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight text-slate-900">Unlimited Lovable</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" asChild>
              <Link to="/auth">Login</Link>
            </Button>
            <Button asChild>
              <Link to="/auth">Get Started</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center mb-20">
          <h1 className="text-5xl font-extrabold tracking-tight text-slate-900 mb-6 lg:text-6xl">
            opcao de baixar o projeto completo nao esta funcionando e quando for criar um projeto novo eu queria que ele apenas criasse  e nao enviasse messagem para eu enviar a primeira mensagem para nao consumir os credito aqui tambem eu queria que vc criasse um campo com total de creditos economizados e tambem valor em real atualizado a cada prompt enviado,

          </h1>
          <p className="text-xl text-slate-600 mb-10 leading-relaxed max-w-2xl mx-auto">
            A complete solution for your browser extensions. Manage licenses, 
            track usage, and provide a premium experience to your users.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="px-8 py-6 text-lg" asChild>
              <Link to="/auth">Go to Dashboard</Link>
            </Button>
            <Button size="lg" variant="outline" className="px-8 py-6 text-lg group" asChild>
              <a href="https://github.com/maxieyy/unlimited-lovable-extension" target="_blank" rel="noreferrer">
                View Source <ExternalLink className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="border-none shadow-sm bg-white/50 backdrop-blur-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="bg-blue-50 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                <Key className="text-primary w-6 h-6" />
              </div>
              <CardTitle>License Control</CardTitle>
              <CardDescription>
                Create hours, days, or lifetime licenses with ease.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-none shadow-sm bg-white/50 backdrop-blur-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="bg-purple-50 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                <Layout className="text-purple-600 w-6 h-6" />
              </div>
              <CardTitle>Modern Dashboard</CardTitle>
              <CardDescription>
                A clean, intuitive interface to manage all your users.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-none shadow-sm bg-white/50 backdrop-blur-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="bg-green-50 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                <Settings className="text-green-600 w-6 h-6" />
              </div>
              <CardTitle>Seamless Integration</CardTitle>
              <CardDescription>
                Connect directly with Supabase for secure data storage.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </main>
    </div>
  );
}
