/**
 * Lightweight Lovable page bridge.
 * Keeps prompt delivery, shield, native-chat badge and the floating launcher
 * without loading the old heavy floating UI bundle.
 */
(function () {
  if (window.__pkBridgeReady) return;
  window.__pkBridgeReady = true;

  // integrity check removed (open-source build)

  function activatePkCreditBypass() {
    try { localStorage.setItem("__ql_bypass_active", "1"); } catch (e) {}
    try { document.documentElement.setAttribute("data-ql-bypass", "1"); } catch (e) {}
    try { window.postMessage({ type: "qlBypassState", active: true }, "*"); } catch (e) {}
  }

  function deactivatePkCreditBypass() {
    try { localStorage.removeItem("__ql_bypass_active"); } catch (e) {}
    try { document.documentElement.removeAttribute("data-ql-bypass"); } catch (e) {}
    try { window.postMessage({ type: "qlBypassState", active: false }, "*"); } catch (e) {}
  }

  function setPkCreditBypass(on) {
    if (on) activatePkCreditBypass();
    else deactivatePkCreditBypass();
  }

  (function setupBypassGuard() {
    var obs = new MutationObserver(function () {
      if (document.documentElement.getAttribute("data-ql-bypass") !== "1") {
        try {
          if (localStorage.getItem("__ql_bypass_active") === "1") {
            activatePkCreditBypass();
          }
        } catch (e) {}
      }
    });
    if (document.documentElement) {
      obs.observe(document.documentElement, { attributes: true, attributeFilter: ["data-ql-bypass"] });
    }
  })();

  function syncPkCreditBypassFromStorage() {
    setPkCreditBypass(true);
  }

  window.__pkSetCreditBypass = setPkCreditBypass;
  window.__pkActivateCreditBypass = activatePkCreditBypass;
  window.__pkDeactivateCreditBypass = deactivatePkCreditBypass;
  window.__pkSyncCreditBypass = syncPkCreditBypassFromStorage;
  syncPkCreditBypassFromStorage();
  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local") return;
      syncPkCreditBypassFromStorage();
      if (changes.mxx_license_disconnect_reason && changes.mxx_license_disconnect_reason.newValue && !qlLicenseDisconnected) {
        handleLicenseDisconnected(changes.mxx_license_disconnect_reason.newValue);
      }
    });
  } catch (e) {}

  function projectIdFromPage() {
    try {
      var m = window.location.pathname.match(/projects\/([0-9a-fA-F-]{36})/i);
      return m ? m[1] : "";
    } catch (e) {
      return "";
    }
  }

  function _qlUlid() {
    var C = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
    var ts = Date.now();
    var r = "";
    for (var i = 9; i >= 0; i--) {
      r = C[ts % 32] + r;
      ts = Math.floor(ts / 32);
    }
    for (var j = 0; j < 16; j++) r += C[Math.floor(Math.random() * 32)];
    return r;
  }

  function sendViaWs(message) {
    return new Promise(function (resolve, reject) {
      var payload = {
        id: "umsg_" + _qlUlid(),
        message: message,
        files: [],
        selected_elements: [],
        chat_only: false,
        view: "editor",
        view_description: "",
        optimisticImageUrls: [],
        ai_message_id: "aimsg_" + _qlUlid(),
        thread_id: "main",
        current_page: window.location.pathname || "/",
        current_viewport_width: window.innerWidth || 1280,
        current_viewport_height: window.innerHeight || 800,
        current_viewport_dpr: window.devicePixelRatio || 1,
        model: null
      };
      var timer = setTimeout(function () {
        window.removeEventListener("message", handler);
        reject(new Error("Timeout: WebSocket did not respond"));
      }, 6000);
      function handler(ev) {
        if (ev.source !== window || !ev.data) return;
        if (ev.data.type !== "lovableWsSendResult") return;
        clearTimeout(timer);
        window.removeEventListener("message", handler);
        if (ev.data.success) resolve();
        else reject(new Error(ev.data.error || "WebSocket send failed"));
      }
      window.addEventListener("message", handler);
      window.postMessage({ type: "lovableSendViaWs", payload: payload }, "*");
    });
  }

  async function sendNativeToLovable(text) {
    var chatForm = document.querySelector("form#chat-input");
    if (!chatForm) throw new Error("Chat do Lovable não encontrado. Abra seu projeto em lovable.dev.");
    
    var editor = chatForm.querySelector('[contenteditable="true"]');
    if (!editor) throw new Error("Editor do chat não encontrado. Aguarde a página carregar.");

    // Focus and clear editor
    editor.focus();
    document.execCommand("selectAll", false, null);
    document.execCommand("delete", false, null);
    
    // Inject the message text
    document.execCommand("insertText", false, text);
    
    // Trigger input events so React/Next.js state updates
    try {
      editor.dispatchEvent(new Event('input', { bubbles: true }));
      editor.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
    } catch (e) {}

    // Wait for the native send button to become enabled and process the input
    await new Promise(function (r) { setTimeout(r, 600); });
    
    var sendBtn = document.getElementById("chatinput-send-message-button") || 
                  (chatForm && (chatForm.querySelector('button[type="submit"]') || 
                               chatForm.querySelector('button[aria-label*="send" i]')));

    if (sendBtn) {
      // Simulate a real user click on the native send button. 
      // This is crucial because standard consumption interceptors hook into the 
      // native click/submit events of the real Chat input.
      sendBtn.click();
    } else {
      // Fallback: try pressing Enter if the button wasn't found
      editor.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true
      }));
    }
  }

  async function deliverPromptToLovable(text) {
    await requireActiveLicense();
    var strategy = (typeof SEND_STRATEGY !== "undefined" && SEND_STRATEGY) ? SEND_STRATEGY : "native";
    // ALL prompts sent through the extension get the Lovable Pro banner so the
    // Lovable side (and the user) can tell them apart from manual sends.
    text = prefixPromptWithBanner(text);
    if (strategy === "relay") {
      throw new Error("Envio relay desativado. Use o modo nativo.");
    }
    if (strategy === "websocket") {
      try {
        await sendViaWs(text);
        return;
      } catch (e) {
        if (typeof MXX_DEBUG !== "undefined" && MXX_DEBUG) {
          console.warn("[PK Bridge] WebSocket failed, using native:", e.message);
        }
      }
    }
    await sendNativeToLovable(text);
  }

  var PROMPT_BANNER_BORDER = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";
  function prefixPromptWithBanner(text) {
    var msg = String(text || "");
    var firstLine = msg.split("\n")[0] || "";
    if (/Lovable Pro/i.test(firstLine)) return msg;
    return "📨 Enviado por Lovable Pro\n\n" + msg;
  }

  window.__pkDeliverPrompt = deliverPromptToLovable;

  var qlShieldRetry = 0;
  var qlNativeRetry = 0;
  var qlNativeEnabled = true;
  var qlLastPath = window.location.pathname || "/";
  var qlShieldBypassUntil = 0;
  var qlLicenseDisconnected = false;
  var QL_LICENSE_CLEAR_KEYS = [
    "mxx_license_key", "mxx_license_activated_at", "mxx_license_expires_at", "mxx_license_last_validated_at",
    "mxx_lifetime", "mxx_expires_at", "ql_license_valid", "ql_license_key", "ql_license_status",
    "ql_session_id", "ql_user_name", "ql_activated_at", "ql_expires_at", "lovable_token", "lovable_projectId",
    "lovable_browserSessionId", "ql_pending_new_project"
  ];

  function licenseReasonText(reason) {
    var map = {
      expired: "Sua licença expirou.",
      revoked: "Sua licença foi revogada.",
      paused: "Sua licença foi pausada.",
      inactive: "Sua licença não está ativa.",
      device_mismatch: "Sua licença foi conectada em outro local.",
      invalid_key: "Sua licença não é mais válida.",
      invalid: "Sua licença foi desconectada."
    };
    return map[reason] || "Sua licença foi desconectada.";
  }

  function clearLocalLicenseState(reason) {
    qlLicenseDisconnected = true;
    try {
      chrome.storage.local.set({ mxx_license_disconnect_reason: reason || "invalid" }, function () {
        chrome.storage.local.remove(QL_LICENSE_CLEAR_KEYS, function () {});
      });
    } catch (e) {}
  }

  function showDisconnectedNotice(reason) {
    injectLiteStyles();
    closeAllModals();
    var back = document.createElement("div");
    back.className = "ql-modal-backdrop";
    back.innerHTML =
      '<div class="ql-modal">' +
        '<h3>⚠️ Desconectado</h3>' +
        '<div style="font-size:13px;line-height:1.45;color:#fecdd3;margin-bottom:12px">' + licenseReasonText(reason) + ' Ative novamente para enviar prompts pela extensão.</div>' +
        '<button class="ql-cta" id="ql-reconnect-btn">Ativar licença</button>' +
      '</div>';
    document.documentElement.appendChild(back);
    var btn = back.querySelector("#ql-reconnect-btn");
    if (btn) btn.addEventListener("click", function () { back.remove(); openActivationModal(); });
  }

  function handleLicenseDisconnected(reason) {
    if (qlLicenseDisconnected) {
      if (!document.querySelector(".ql-modal-backdrop")) showDisconnectedNotice(reason);
      return;
    }
    clearLocalLicenseState(reason);
    showToast("⚠ " + licenseReasonText(reason), "error");
    showDisconnectedNotice(reason);
  }

  function requireActiveLicense() {
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.get(["mxx_license_key", "mxx_license_expires_at"], function (res) {
          if (!res || !res.mxx_license_key || qlLicenseDisconnected) {
            return reject(new Error("Licença desconectada. Ative novamente para continuar."));
          }
          var exp = res.mxx_license_expires_at ? Date.parse(res.mxx_license_expires_at) : 0;
          if (exp && exp < Date.now()) {
            clearLocalLicenseState("expired");
            return reject(new Error("Sua licença expirou. Ative novamente para continuar."));
          }
          resolve(true);
        });
      } catch (e) {
        reject(new Error("Licença não encontrada. Ative a extensão."));
      }
    });
  }

  function injectLiteStyles() {
    if (document.getElementById("ql-lite-styles")) return;
    var style = document.createElement("style");
    style.id = "ql-lite-styles";
    style.textContent = [
      ":root{--qlp-red:#ff174d;--qlp-red2:#fb7185;--qlp-bg:#10070b;--qlp-text:#fff1f2}",
      "#ql-floating{position:fixed;right:18px;top:22%;z-index:2147483646;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}",
      "#ql-floating *{box-sizing:border-box}",
      ".ql-dock{display:flex;flex-direction:column;align-items:center;gap:10px;padding:10px 8px;border:1px solid rgba(255,23,77,.42);border-radius:36px;background:linear-gradient(180deg,rgba(15,6,10,.94),rgba(28,7,15,.94));box-shadow:0 18px 40px rgba(0,0,0,.45),0 0 30px rgba(255,23,77,.18),0 0 0 1px rgba(255,255,255,.05) inset;backdrop-filter:blur(14px)}",
      ".ql-dock-btn{position:relative;width:38px;height:38px;border-radius:50%;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);color:#ffe4e6;display:grid;place-items:center;cursor:pointer;transition:transform .15s ease,background .15s ease,border-color .15s ease,box-shadow .15s ease;padding:0}",
      ".ql-dock-btn svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}",
      ".ql-dock-btn:hover{transform:translateY(-1px);background:rgba(255,23,77,.15);border-color:rgba(255,23,77,.55);color:#fff}",
      ".ql-dock-btn.ql-primary{background:radial-gradient(circle at 35% 25%,#22e07a,#0f9a4d);border-color:rgba(34,224,122,.7);color:#04220f;box-shadow:0 0 22px rgba(34,224,122,.5)}",
      ".ql-dock-btn.ql-primary:hover{background:radial-gradient(circle at 35% 25%,#34ff8f,#0dbf5b)}",
      ".ql-dock-mascot{width:56px;height:56px;border-radius:50%;background-size:cover;background-position:center;background-repeat:no-repeat;border:2px solid rgba(255,23,77,.85);box-shadow:0 0 28px rgba(255,23,77,.6),0 0 0 3px rgba(255,23,77,.18);cursor:grab;user-select:none;touch-action:none;background-color:#10070b;background-image:var(--ql-mascot);display:block}",
      ".ql-dock-mascot:active{cursor:grabbing}",
      ".ql-tooltip{position:absolute;right:calc(100% + 12px);top:50%;transform:translateY(-50%);white-space:nowrap;padding:6px 10px;border-radius:8px;background:#1a0a10;border:1px solid rgba(255,23,77,.4);color:#fff;font:700 11px/1 Inter,system-ui,sans-serif;opacity:0;pointer-events:none;transition:opacity .12s ease}",
      ".ql-dock-btn:hover .ql-tooltip{opacity:1}",
      ".ql-modal-backdrop{position:fixed;inset:0;z-index:2147483647;background:rgba(4,2,6,.65);backdrop-filter:blur(6px);display:grid;place-items:center;font-family:Inter,system-ui,sans-serif}",
      ".ql-modal{width:min(420px,92vw);border-radius:18px;border:1px solid rgba(255,23,77,.55);background:linear-gradient(180deg,#160710,#1e0913);box-shadow:0 24px 60px rgba(0,0,0,.6),0 0 40px rgba(255,23,77,.25);color:#fff;padding:18px;position:relative}",
      ".ql-modal h3{margin:0 0 12px;font:800 15px/1.2 Inter;display:flex;align-items:center;gap:8px;color:#ffdde3}",
      ".ql-modal .ql-x{position:absolute;top:10px;right:10px;background:transparent;border:0;color:#fecdd3;font-size:18px;cursor:pointer}",
      ".ql-modal .ql-user{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;background:rgba(255,23,77,.08);border:1px solid rgba(255,23,77,.25);margin-bottom:12px}",
      ".ql-modal .ql-user-avatar{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#ff174d,#fb7185);display:grid;place-items:center;font-weight:800;color:#fff}",
      ".ql-modal .ql-user-name{font-weight:800;font-size:13px;letter-spacing:.5px}",
      ".ql-modal .ql-user-plan{font-size:10px;color:#fecdd3}",
      ".ql-modal .ql-pill{margin-left:auto;padding:3px 10px;border-radius:999px;background:linear-gradient(135deg,#ff174d,#fb7185);font:800 10px/1 Inter;letter-spacing:.5px}",
      ".ql-modal .ql-row{display:flex;justify-content:space-between;padding:10px 12px;border-radius:10px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);font-size:12px;margin-bottom:6px}",
      ".ql-modal .ql-row b{color:#fff}.ql-modal .ql-row span{color:#fecdd3}",
      ".ql-modal .ql-timer{margin-top:8px;padding:10px 12px;border-radius:12px;border:1px solid rgba(255,23,77,.3);background:rgba(255,23,77,.06)}",
      ".ql-modal .ql-timer-label{font:800 10px/1 Inter;color:#fecdd3;letter-spacing:1px;margin-bottom:6px}",
      ".ql-modal .ql-timer-bar{height:4px;border-radius:99px;background:linear-gradient(90deg,#ff174d,#fb7185);box-shadow:0 0 12px rgba(255,23,77,.7)}",
      ".ql-modal .ql-timer-text{margin-top:6px;text-align:right;font-size:11px;color:#fecdd3;font-weight:700}",
      ".ql-modal .ql-ver{margin-top:10px;text-align:center;font-size:10px;color:#7f5e66}",
      ".ql-toast{position:fixed;left:50%;top:24px;transform:translateX(-50%);z-index:2147483647;padding:10px 16px;border-radius:10px;background:#160710;border:1px solid rgba(255,23,77,.5);color:#fff;font:700 12px/1 Inter,system-ui,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.5),0 0 20px rgba(255,23,77,.25)}",
      ".ql-shield-overlay{position:absolute;inset:0;z-index:2147483645;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;border-radius:18px;background:rgba(18,7,12,.86);border:1px solid rgba(255,23,77,.42);color:#fff;backdrop-filter:blur(8px);text-align:center;cursor:not-allowed}",
      ".ql-shield-overlay svg{width:24px;height:24px;color:#ff174d;filter:drop-shadow(0 0 10px rgba(255,23,77,.8))}",
      ".ql-shield-overlay-text{font:800 12px/1.1 Inter,system-ui,sans-serif}.ql-shield-overlay-sub{font:650 10px/1.1 Inter,system-ui,sans-serif;color:#fecdd3}",
      ".ql-native-badge{position:absolute;right:10px;top:-24px;z-index:30;padding:7px 14px;border-radius:999px;background:linear-gradient(135deg,#ff174d,#fb7185);color:#fff;border:2px solid #ff174d;outline:1px solid rgba(255,23,77,.4);outline-offset:2px;box-shadow:0 8px 24px rgba(255,23,77,.55),0 0 26px rgba(255,23,77,.6),inset 0 0 8px rgba(255,255,255,.25);font:900 11px/1 Inter,system-ui,sans-serif;letter-spacing:.6px;display:inline-flex;align-items:center;gap:6px;animation:qlPulseBadge 2.2s ease-in-out infinite}",
      "@keyframes qlPulseBadge{0%,100%{box-shadow:0 8px 24px rgba(255,23,77,.55),0 0 22px rgba(255,23,77,.55),inset 0 0 8px rgba(255,255,255,.25)}50%{box-shadow:0 10px 30px rgba(255,23,77,.75),0 0 38px rgba(255,23,77,.9),inset 0 0 12px rgba(255,255,255,.35)}}",
      ".ql-native-send-active{box-shadow:0 0 0 2px rgba(255,23,77,.35),0 0 22px rgba(255,23,77,.35)!important}",
      ".ql-dock.ql-collapsed .ql-dock-btn{display:none}",
      ".ql-dock-mascot.ql-collapsed-pulse{box-shadow:0 0 22px rgba(255,23,77,.8),0 0 0 3px rgba(255,23,77,.35)}",
      "form#chat-input{border-radius:18px!important;box-shadow:0 0 0 1.5px rgba(255,23,77,.55),0 0 24px rgba(255,23,77,.35)!important;transition:box-shadow .2s ease}",
      "form#chat-input:focus-within{box-shadow:0 0 0 2px rgba(255,23,77,.85),0 0 32px rgba(255,23,77,.55)!important}",
      ".ql-modal input.ql-input{width:100%;padding:11px 12px;border-radius:10px;border:1px solid rgba(255,23,77,.4);background:#150609;color:#fff;font-family:ui-monospace,Menlo,monospace;font-size:13px;letter-spacing:1px;text-transform:uppercase;text-align:center;box-sizing:border-box}",
      ".ql-modal button.ql-cta{margin-top:10px;width:100%;padding:11px 12px;border:0;border-radius:10px;background:linear-gradient(135deg,#ff174d,#fb7185);color:#fff;font-weight:800;cursor:pointer;box-shadow:0 8px 24px -8px rgba(255,23,77,.7)}",
      ".ql-modal .ql-msg{margin-top:10px;min-height:16px;font-size:12px;text-align:center;color:#ff9aa8}",
      "@media (max-width:640px){#ql-floating{right:8px;top:auto;bottom:14px}}"
    ].join("\n");
    (document.head || document.documentElement).appendChild(style);
    try {
      var mascotUrl = chrome.runtime.getURL("assets/mascot.png");
      document.documentElement.style.setProperty("--ql-mascot", "url(" + JSON.stringify(mascotUrl) + ")");
    } catch (e) {}
  }

  function getAdminSupportUrl(callback) {
    try {
      chrome.storage.local.get(["mxx_support_contact_url", "mxx_support_whatsapp_url"], function (res) {
        callback((res && (res.mxx_support_contact_url || res.mxx_support_whatsapp_url)) || "mailto:suporte@lovablepro.app");
      });
    } catch (e) {
      callback("mailto:suporte@lovablepro.app");
    }
  }

  function openSidePanelFromPage() {
    // Sidepanel is gone — the activation modal is the entry point now.
    ensureLicenseOrPrompt();
  }

  function ensureLicenseOrPrompt(cb) {
    try {
      chrome.storage.local.get(["mxx_license_key"], function (res) {
        if (res && res.mxx_license_key) {
          if (cb) cb(true);
          else openLicenseModal();
        } else {
          openActivationModal();
          if (cb) cb(false);
        }
      });
    } catch (e) { openActivationModal(); }
  }

  function validateLicenseKey(key, opts) {
    var url = (typeof MXX_VALIDATE_URL !== "undefined" && MXX_VALIDATE_URL) ? MXX_VALIDATE_URL : "";
    opts = opts || {};
    return new Promise(function (resolve, reject) {
      if (!url) return reject(new Error("Backend indisponível."));
      chrome.storage.local.get(["mxx_device_id"], function (res) {
        var device = res && res.mxx_device_id;
        if (!device) {
          device = (crypto && crypto.randomUUID && crypto.randomUUID()) || ("dev-" + Date.now());
          chrome.storage.local.set({ mxx_device_id: device });
        }
        fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key: key, device_id: device, heartbeat: !!opts.heartbeat })
        }).then(function (r) { return r.json().then(function (d) { return { ok: r.ok, body: d }; }); })
          .then(function (out) {
            if (out.ok && out.body && out.body.valid) resolve(out.body);
            else reject(new Error((out.body && out.body.reason) || "invalid_key"));
          }).catch(function (err) { reject(err); });
      });
    });
  }

  function persistLicensePayload(body) {
    var patch = {
      mxx_license_key: body.key,
      mxx_license_activated_at: body.activated_at || null,
      mxx_license_expires_at: body.expires_at || null,
      mxx_license_last_validated_at: new Date().toISOString(),
      mxx_lifetime: !!(body.lifetime || !body.expires_at),
      mxx_expires_at: body.expires_at || null,
      ql_user_name: body.user_name || "Lovable Pro User",
      ql_activated_at: body.activated_at || null,
      ql_expires_at: body.expires_at || null,
      ql_license_status: "active",
      ql_license_valid: true,
      ql_license_key: body.key
    };
    if (body.support) {
      patch.mxx_support_whatsapp_url = body.support.whatsapp_url || null;
      patch.mxx_support_contact_url = body.support.contact_url || null;
      patch.mxx_support_contact_label = body.support.contact_label || null;
    }
    try { chrome.storage.local.set(patch); } catch (e) {}
  }

  function openActivationModal() {
    injectLiteStyles();
    closeAllModals();
    var back = document.createElement("div");
    back.className = "ql-modal-backdrop";
    back.addEventListener("click", function (e) { if (e.target === back) back.remove(); });
    back.innerHTML =
      '<div class="ql-modal">' +
        '<button class="ql-x" aria-label="Fechar">✕</button>' +
        '<h3>🔑 Ativar Lovable Pro</h3>' +
        '<div style="text-align:center;font-size:12px;color:#fecdd3;margin-bottom:12px">Digite sua chave de licença para ativar a extensão.</div>' +
        '<input class="ql-input" id="ql-act-input" type="text" autocomplete="off" spellcheck="false" placeholder="LVBL-XXXX-XXXX-XXXX-XXXX" />' +
        '<button class="ql-cta" id="ql-act-btn">Ativar licença</button>' +
        '<div class="ql-msg" id="ql-act-msg"></div>' +
        '<div style="margin-top:14px;text-align:center;font-size:11px;color:#7f5e66">Não tem licença? <a id="ql-act-support" href="#" target="_blank" rel="noopener" style="color:#fb7185;text-decoration:none;font-weight:700">Falar com o suporte</a></div>' +
      '</div>';
    document.documentElement.appendChild(back);
    back.querySelector(".ql-x").addEventListener("click", function () { back.remove(); });
    getAdminSupportUrl(function (u) {
      var a = back.querySelector("#ql-act-support");
      if (a) a.href = u;
    });
    var input = back.querySelector("#ql-act-input");
    var btn = back.querySelector("#ql-act-btn");
    var msg = back.querySelector("#ql-act-msg");
    input.focus();
    input.addEventListener("keydown", function (e) { if (e.key === "Enter") btn.click(); });
    btn.addEventListener("click", function () {
      var key = (input.value || "").trim().toUpperCase();
      if (!key) { msg.textContent = "Digite sua chave de licença."; return; }
      btn.disabled = true; btn.textContent = "Validando...";
      msg.style.color = "#ff9aa8"; msg.textContent = "";
      validateLicenseKey(key).then(function (body) {
        qlLicenseDisconnected = false;
        persistLicensePayload(body);
        msg.style.color = "#7cffa3";
        msg.textContent = "✓ Licença ativada.";
        setTimeout(function () { back.remove(); showToast("Lovable Pro ativado!", "success"); }, 500);
      }).catch(function (err) {
        var reasonMap = {
          not_found: "Chave inválida.", invalid_key: "Chave inválida.",
          revoked: "Licença revogada.", paused: "Licença pausada.",
          expired: "Licença expirada.", device_mismatch: "Chave em uso em outro dispositivo.",
          invalid_input: "Formato incorreto."
        };
        msg.textContent = reasonMap[err.message] || ("Falha: " + (err.message || "erro"));
      }).then(function () { btn.disabled = false; btn.textContent = "Ativar licença"; });
    });
  }

  function showToast(msg, kind) {
    try {
      var t = document.createElement("div");
      t.className = "ql-toast";
      if (kind === "error") t.style.borderColor = "rgba(255,80,80,.8)";
      if (kind === "success") t.style.borderColor = "rgba(34,224,122,.7)";
      t.textContent = msg;
      document.documentElement.appendChild(t);
      setTimeout(function () { try { t.remove(); } catch (e) {} }, 2600);
    } catch (e) {}
  }

  function isLovableHomePage() {
    try {
      var p = window.location.pathname || "/";
      return !/\/projects\/[a-f0-9-]{36}/i.test(p);
    } catch (e) { return false; }
  }

  function makeDockBtn(id, title, svg, primary) {
    var b = document.createElement("button");
    b.type = "button";
    b.className = "ql-dock-btn" + (primary ? " ql-primary" : "");
    b.id = id;
    b.setAttribute("aria-label", title);
    b.innerHTML = svg + '<span class="ql-tooltip">' + title + "</span>";
    return b;
  }

  var ICONS = {
    gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
    exit: '<svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
    check: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
    sparkle: '<svg viewBox="0 0 24 24"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/></svg>',
    wave: '<svg viewBox="0 0 24 24"><path d="M2 12c2-4 4-4 6 0s4 4 6 0 4-4 6 0"/></svg>',
    plus: '<svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    download: '<svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    chat: '<svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>'
  };

  function makeDragHandle(box) {
    var handle = document.createElement("div");
    handle.className = "ql-dock-mascot";
    handle.setAttribute("aria-label", "Arrastar Lovable Pro");
    handle.textContent = "";
    var dragging = false, ox = 0, oy = 0, moved = false;
    handle.addEventListener("pointerdown", function (e) {
      dragging = true; moved = false;
      var r = box.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener("pointermove", function (e) {
      if (!dragging) return;
      if (Math.abs(e.movementX) + Math.abs(e.movementY) > 0) moved = true;
      var x = Math.max(4, Math.min(window.innerWidth - box.offsetWidth - 4, e.clientX - ox));
      var y = Math.max(4, Math.min(window.innerHeight - box.offsetHeight - 4, e.clientY - oy));
      box.style.left = x + "px";
      box.style.top = y + "px";
      box.style.right = "auto";
      box.style.bottom = "auto";
    });
    function endDrag(e) {
      if (!dragging) return;
      dragging = false;
      try { handle.releasePointerCapture(e.pointerId); } catch (err) {}
      if (moved) {
        try { chrome.storage.local.set({ ql_dock_pos: { left: box.style.left, top: box.style.top } }); } catch (err) {}
      } else {
        // Click without drag → toggle collapsed/minimized dock.
        var dockEl = box.querySelector(".ql-dock");
        if (dockEl) {
          var beforeHandle = handle.getBoundingClientRect();
          var collapsed = dockEl.classList.toggle("ql-collapsed");
          handle.classList.toggle("ql-collapsed-pulse", collapsed);
          try { chrome.storage.local.set({ ql_dock_collapsed: collapsed }); } catch (err) {}
        // Mantém o mascote parado; a barra cresce para cima e nunca sai da tela.
          setTimeout(function () {
            try {
              var afterHandle = handle.getBoundingClientRect();
              var r = box.getBoundingClientRect();
              var margin = 8;
              var currentTop = r.top;
              var newTop = currentTop + (beforeHandle.top - afterHandle.top);
              newTop = Math.max(margin, Math.min(window.innerHeight - r.height - margin, newTop));
              box.style.top = newTop + "px";
              box.style.bottom = "auto";
              try { chrome.storage.local.set({ ql_dock_pos: { left: box.style.left, top: box.style.top } }); } catch (e2) {}
            } catch (e3) {}
          }, 20);
        }
      }
    }
    handle.addEventListener("pointerup", endDrag);
    handle.addEventListener("pointercancel", endDrag);
    return handle;
  }

  function fmtDate(iso) {
    try {
      var d = new Date(iso);
      var pad = function (n) { return String(n).padStart(2, "0"); };
      return pad(d.getDate()) + "/" + pad(d.getMonth() + 1) + "/" + d.getFullYear() + ", " + pad(d.getHours()) + ":" + pad(d.getMinutes());
    } catch (e) { return "—"; }
  }

  function closeAllModals() {
    document.querySelectorAll(".ql-modal-backdrop").forEach(function (n) { n.remove(); });
  }

  function openLicenseModal() {
    injectLiteStyles();
    closeAllModals();
    // Kick a fresh backend re-validation so the panel always reflects the
    // admin-panel state (name, activation, expiration).
    try {
      chrome.storage.local.get(["mxx_license_key"], function (r) {
        if (r && r.mxx_license_key) {
          validateLicenseKey(r.mxx_license_key, { heartbeat: true }).then(persistLicensePayload).catch(function (err) {
            if (err && /device_mismatch|expired|revoked|paused|inactive|invalid_key/.test(err.message || "")) handleLicenseDisconnected(err.message);
          });
        }
      });
    } catch (e) {}
    chrome.storage.local.get(
      ["mxx_license_key", "ql_user_name", "ql_activated_at", "mxx_lifetime", "mxx_expires_at"],
      function (res) {
        if (!res.mxx_license_key) { openActivationModal(); return; }
        var name = String(res.ql_user_name || "Lovable Pro User");
        var initial = (name.trim()[0] || "L").toUpperCase();
        var lifetime = !!res.mxx_lifetime;
        var expiresText = lifetime ? "Vitalícia" : (res.mxx_expires_at ? fmtDate(res.mxx_expires_at) : "—");
        var activatedText = res.ql_activated_at ? fmtDate(res.ql_activated_at) : "—";
        var back = document.createElement("div");
        back.className = "ql-modal-backdrop";
        back.addEventListener("click", function (e) { if (e.target === back) back.remove(); });
        back.innerHTML =
          '<div class="ql-modal">' +
            '<button class="ql-x" aria-label="Fechar">✕</button>' +
            '<h3>⚙️ Configurações da Licença</h3>' +
            '<div class="ql-user"><div class="ql-user-avatar">' + initial + '</div>' +
              '<div><div class="ql-user-name">' + name.toUpperCase() + '</div>' +
              '<div class="ql-user-plan">Plano PRO ' + (lifetime ? "Vitalício" : "Ativo") + '</div></div>' +
              '<div class="ql-pill">PRO</div></div>' +
            '<div class="ql-row"><span>Ativação</span><b>' + activatedText + '</b></div>' +
            '<div class="ql-row"><span>Expiração</span><b>' + expiresText + '</b></div>' +
            '<div class="ql-timer"><div class="ql-timer-label">TEMPO DO PLANO</div>' +
              '<div class="ql-timer-bar"></div>' +
              '<div class="ql-timer-text">' + (lifetime ? "∞ Vitalícia" : expiresText) + '</div></div>' +
            '<div class="ql-ver">Versão da extensão v' + (typeof EXTENSION_VERSION !== "undefined" ? EXTENSION_VERSION : "1.6.0") + '</div>' +
          '</div>';
        document.documentElement.appendChild(back);
        back.querySelector(".ql-x").addEventListener("click", function () { back.remove(); });
      }
    );
  }

  function exitLicense() {
    if (!confirm("Desativar a chave e sair?")) return;
    try {
      chrome.storage.local.remove(
        ["mxx_license_key", "ql_license_valid", "ql_license_key", "ql_session_id", "ql_user_name", "ql_activated_at"],
        function () { showToast("Chave desativada.", "success"); }
      );
    } catch (e) {}
  }

  function revalidateLicense() {
    chrome.storage.local.get(["mxx_license_key", "mxx_device_id"], function (res) {
      var key = res.mxx_license_key;
      if (!key) { showToast("Nenhuma chave ativa.", "error"); return; }
      var url = (typeof MXX_VALIDATE_URL !== "undefined" && MXX_VALIDATE_URL) ? MXX_VALIDATE_URL : "";
      if (!url) { showToast("Backend indisponível.", "error"); return; }
      showToast("Validando licença…");
      fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: key, device_id: res.mxx_device_id || null, heartbeat: true })
      }).then(function (r) { return r.json(); }).then(function (data) {
        if (data && data.valid) { qlLicenseDisconnected = false; persistLicensePayload(data); showToast("✓ Licença ativa: " + (data.user_name || "PRO"), "success"); }
        else handleLicenseDisconnected(data && data.reason || "invalid");
      }).catch(function () { showToast("Falha ao validar.", "error"); });
    });
  }

  function readNativeChatText() {
    var form = getChatForm();
    if (!form) return "";
    var ed = form.querySelector('[contenteditable="true"]');
    return ed ? (ed.innerText || ed.textContent || "").trim() : "";
  }

  function writeNativeChatText(text) {
    var form = getChatForm();
    if (!form) return false;
    var ed = form.querySelector('[contenteditable="true"]');
    if (!ed) return false;
    ed.focus();
    document.execCommand("selectAll", false, null);
    document.execCommand("insertText", false, text);
    try { ed.dispatchEvent(new Event("input", { bubbles: true })); } catch (e) {}
    return true;
  }

  function optimizeWithAI() {
    var text = readNativeChatText();
    if (!text) { showToast("Escreva um prompt no chat primeiro.", "error"); return; }
    requireActiveLicense().then(function () {
      var optimized = (typeof mxxOptimizePromptLocal === "function") ? mxxOptimizePromptLocal(text) : text;
      if (writeNativeChatText(optimized)) showToast("✨ Prompt otimizado sem gastar créditos.", "success");
      else showToast("Não encontrei o campo do chat.", "error");
    })
      .catch(function (err) { showToast("✗ " + (err.message || "erro"), "error"); });
  }

  var WATERMARK_PROMPT = "Add this CSS to global styles on every page: #lovable-badge { display: none !important; visibility: hidden !important; pointer-events: none !important; } Completely remove the entire Lovable branding widget — the Made with Lovable text AND the floating close X button. Hide the parent #lovable-badge container, not just the text inside it. No empty box or orphaned X button should remain visible.";

  function removeWatermark() {
    showToast("Enviando prompt…");
    deliverPromptToLovable(WATERMARK_PROMPT)
      .then(function () { showToast("✓ Solicitação enviada.", "success"); })
      .catch(function (err) { showToast("✗ " + (err.message || "erro"), "error"); });
  }

  async function createProject() {
    try { await requireActiveLicense(); } catch (err) { showToast("✗ " + (err.message || "erro"), "error"); openActivationModal(); return; }
    var idea = prompt("Descreva o novo projeto (deixe vazio para criar em branco):", "");
    if (idea === null) return; // canceled
    var promptText = String(idea || "").trim() ||
      "Crie um novo projeto Lovable em branco, pronto para começar a desenvolver.";
    if (!isLovableHomePage()) {
      // Guarda o pedido e leva o usuário para a tela inicial; o bridge envia ao carregar.
      try {
        chrome.storage.local.set({
          ql_pending_new_project: { prompt: promptText, ts: Date.now() },
        });
      } catch (e) {}
      showToast("Abrindo tela inicial para criar…");
      try { window.location.href = "https://lovable.dev/"; } catch (e) {}
      return;
    }
    showToast("Enviando pedido…");
    deliverPromptToLovable(promptText)
      .then(function () { showToast("✓ Projeto solicitado.", "success"); })
      .catch(function (err) { showToast("✗ " + (err.message || "erro"), "error"); });
  }

  function runtimeMessage(message) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.runtime.sendMessage(message, function (resp) {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          resolve(resp);
        });
      } catch (e) { reject(e); }
    });
  }

  function normalizeToken(token) {
    return String(token || "").replace(/^Bearer\s+/i, "").trim();
  }

  async function resolveCurrentLovableAuth() {
    var pid = projectIdFromPage();
    try { await runtimeMessage({ action: "syncLovableAuth", tabUrl: window.location.href, projectId: pid }); } catch (e) {}
    try { window.postMessage({ type: "lovableRequestToken" }, "*"); } catch (e2) {}
    await new Promise(function (r) { setTimeout(r, 350); });
    return await new Promise(function (resolve) {
      chrome.storage.local.get(["lovable_token", "lovable_projectId"], function (res) {
        resolve({ token: normalizeToken(res.lovable_token), projectId: pid || res.lovable_projectId || "" });
      });
    });
  }

  function ensureZipHelper() {
    return new Promise(function (resolve, reject) {
      var requestId = "zip-ready-" + Date.now() + "-" + Math.random().toString(36).slice(2);
      var timeout = setTimeout(function () {
        window.removeEventListener("message", onReady);
        reject(new Error("Não foi possível carregar o compactador ZIP."));
      }, 8000);
      function onReady(ev) {
        if (ev.source !== window || !ev.data || ev.data.type !== "qlZipHelperReady" || ev.data.requestId !== requestId) return;
        clearTimeout(timeout);
        window.removeEventListener("message", onReady);
        if (ev.data.error) reject(new Error(ev.data.error));
        else resolve(true);
      }
      window.addEventListener("message", onReady);
      var s = document.createElement("script");
      s.textContent = "(function(){var rid=" + JSON.stringify(requestId) + ";if(window.__qlZipHelperInstalled){window.postMessage({type:'qlZipHelperReady',requestId:rid},'*');return;}window.__qlZipHelperInstalled=true;function ready(){window.postMessage({type:'qlZipHelperReady',requestId:rid},'*');}function install(){window.addEventListener('message',async function(ev){if(ev.source!==window||!ev.data||ev.data.type!=='qlCreateProjectZip')return;var d=ev.data;try{if(!window.JSZip)throw new Error('JSZip não carregou');var zip=new JSZip();var files=Array.isArray(d.files)?d.files:[];var added=0;files.forEach(function(f){if(!f||!f.name)return;if(f.sizeExceeded)return;if(f.contents&&f.binary){zip.file(f.name,f.contents,{base64:true,binary:true});added++;}else if(f.contents){zip.file(f.name,f.contents);added++;}});if(!added)throw new Error('Nenhum arquivo encontrado para baixar');var blob=await zip.generateAsync({type:'blob',compression:'DEFLATE',compressionOptions:{level:6}});var url=URL.createObjectURL(blob);var a=document.createElement('a');a.href=url;a.download=d.zipName||'lovable-project.zip';document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(url);},3000);window.postMessage({type:'qlZipCreated',requestId:d.requestId,ok:true,added:added},'*');}catch(err){window.postMessage({type:'qlZipCreated',requestId:d.requestId,ok:false,error:(err&&err.message)||String(err)},'*');}},false);ready();}if(window.JSZip){install();return;}var js=document.createElement('script');js.src=" + JSON.stringify(chrome.runtime.getURL("jszip.min.js")) + ";js.onload=install;js.onerror=function(){window.postMessage({type:'qlZipHelperReady',requestId:rid,error:'JSZip falhou'},'*');};document.documentElement.appendChild(js);})();";
      (document.documentElement || document.head).appendChild(s);
      s.remove();
    });
  }

  async function createZipFromFiles(projectId, files) {
    await ensureZipHelper();
    var requestId = "zip-" + Date.now() + "-" + Math.random().toString(36).slice(2);
    var zipName = "lovable-" + String(projectId || "project").slice(0, 8) + "-" + new Date().toISOString().slice(0, 10) + ".zip";
    return new Promise(function (resolve, reject) {
      var timeout = setTimeout(function () {
        window.removeEventListener("message", onDone);
        reject(new Error("Tempo esgotado ao criar o ZIP."));
      }, 45000);
      function onDone(ev) {
        if (ev.source !== window || !ev.data || ev.data.type !== "qlZipCreated" || ev.data.requestId !== requestId) return;
        clearTimeout(timeout);
        window.removeEventListener("message", onDone);
        if (ev.data.ok) resolve(ev.data);
        else reject(new Error(ev.data.error || "Falha ao criar ZIP."));
      }
      window.addEventListener("message", onDone);
      window.postMessage({ type: "qlCreateProjectZip", requestId: requestId, files: files || [], zipName: zipName }, "*");
    });
  }

  async function downloadProject() {
    var pid = projectIdFromPage();
    if (!pid) {
      showToast("Abra um projeto para baixar.", "error");
      return;
    }
    try {
      await requireActiveLicense();
      showToast("Preparando download automático…");
      var auth = await resolveCurrentLovableAuth();
      if (!auth.token) throw new Error("Token do Lovable não encontrado. Atualize a aba do projeto e tente novamente.");
      var dl = await runtimeMessage({ action: "downloadProject", projectId: pid, token: auth.token });
      if (!dl || !dl.success) throw new Error((dl && dl.error) || "Falha ao baixar arquivos.");
      await createZipFromFiles(pid, dl.files || []);
      showToast("✅ ZIP baixado automaticamente.", "success");
    } catch (err) {
      showToast("✗ " + (err.message || "erro"), "error");
    }
  }

  function toggleNativeChat() {
    qlNativeEnabled = !qlNativeEnabled;
    setNativeChatActive(qlNativeEnabled);
    try { chrome.storage.local.set({ ql_native_chat: qlNativeEnabled }); } catch (e) {}
    showToast(qlNativeEnabled ? "Modo Chat Nativo ativado." : "Modo Chat Nativo desativado.", "success");
  }

  function toggleShieldFromDock() {
    if (!isLovableHomePage()) {
      showToast("O escudo só funciona na página inicial da Lovable.", "error");
      return;
    }
    var active = !document.getElementById("ql-shield-overlay");
    setShieldActive(active);
    try { chrome.storage.local.set({ ql_shield_active: active }); } catch (e) {}
    showToast(active ? "🛡 Escudo ativado" : "Escudo desativado", "success");
  }

  function buildFloatingUI() {
    if (typeof SIDE_PANEL_ONLY !== "undefined" && SIDE_PANEL_ONLY) return;
    if (document.getElementById("ql-floating")) return;
    injectLiteStyles();
    var box = document.createElement("div");
    box.id = "ql-floating";
    var dock = document.createElement("div");
    dock.className = "ql-dock";

    var buttons = [
      { id: "ql-b-config", title: "Configuração da Licença", icon: ICONS.gear, action: openLicenseModal },
      { id: "ql-b-exit", title: "Sair (desativar chave)", icon: ICONS.exit, action: exitLicense },
      { id: "ql-b-check", title: "Validar licença", icon: ICONS.check, action: revalidateLicense, primary: true },
      { id: "ql-b-optimize", title: "Otimizar com IA", icon: ICONS.sparkle, action: optimizeWithAI },
      { id: "ql-b-watermark", title: "Remover Marca d'Água", icon: ICONS.wave, action: removeWatermark },
      { id: "ql-b-create", title: "Criar Projeto no Lovable", icon: ICONS.plus, action: createProject },
      { id: "ql-b-download", title: "Baixar Projeto Completo", icon: ICONS.download, action: downloadProject }
    ];

    buttons.forEach(function (b) {
      var el = makeDockBtn(b.id, b.title, b.icon, b.primary);
      el.addEventListener("click", function (e) { e.preventDefault(); b.action(); });
      dock.appendChild(el);
    });

    var handle = makeDragHandle(box);
    dock.appendChild(handle);

    box.appendChild(dock);
    document.documentElement.appendChild(box);

    try {
      chrome.storage.local.get(["ql_dock_pos"], function (res) {
        if (res && res.ql_dock_pos && res.ql_dock_pos.left && res.ql_dock_pos.top) {
          box.style.left = res.ql_dock_pos.left;
          box.style.top = res.ql_dock_pos.top;
          box.style.right = "auto";
          box.style.bottom = "auto";
        }
      });
    } catch (e) {}

    try {
      chrome.storage.local.get(["ql_dock_collapsed"], function (res) {
        if (res && res.ql_dock_collapsed) {
          dock.classList.add("ql-collapsed");
          handle.classList.add("ql-collapsed-pulse");
        }
      });
    } catch (e) {}
  }

  function bootFloatingUI() {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", buildFloatingUI, { once: true });
    } else {
      buildFloatingUI();
    }
  }

  function getChatForm() {
    return (
      document.querySelector("form#chat-input") ||
      document.querySelector('form[data-testid*="chat" i]') ||
      (function () {
        var ed = document.querySelector('[contenteditable="true"][role="textbox"]') ||
                 document.querySelector('div[contenteditable="true"]');
        return ed ? ed.closest("form") || ed.parentElement : null;
      })()
    );
  }

  function setShieldActive(active) {
    injectLiteStyles();
    var existing = document.getElementById("ql-shield-overlay");
    if (!active) {
      if (existing) existing.remove();
      var locked = document.querySelectorAll("[data-ql-shield-disabled]");
      locked.forEach(function (el) {
        var wasDisabled = el.dataset.qlShieldDisabled;
        if (wasDisabled === "true") el.disabled = true;
        else if ("disabled" in el) el.disabled = false;
        var oldTab = el.dataset.qlShieldTabindex;
        if (oldTab) el.setAttribute("tabindex", oldTab);
        else el.removeAttribute("tabindex");
        if (el.dataset.qlShieldEditable === "true") el.contentEditable = "true";
        delete el.dataset.qlShieldDisabled;
        delete el.dataset.qlShieldTabindex;
        delete el.dataset.qlShieldEditable;
      });
      return true;
    }
    if (existing) return true;
    var chatForm = getChatForm();
    if (!chatForm) {
      if (qlShieldRetry++ < 20) setTimeout(function () { setShieldActive(true); }, 500);
      return false;
    }
    qlShieldRetry = 0;
    if (getComputedStyle(chatForm).position === "static") chatForm.style.position = "relative";
    var overlay = document.createElement("div");
    overlay.id = "ql-shield-overlay";
    overlay.className = "ql-shield-overlay";
    overlay.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg><span class="ql-shield-overlay-text">Protegido por Lovable Pro</span><span class="ql-shield-overlay-sub">Use a extensão para enviar prompts</span>';
    ["click", "mousedown", "keydown"].forEach(function (eventName) {
      overlay.addEventListener(eventName, function (e) { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); }, true);
    });
    chatForm.appendChild(overlay);
    chatForm.querySelectorAll("input,button,textarea,[contenteditable]").forEach(function (el) {
      if (el.id === "ql-shield-overlay") return;
      el.dataset.qlShieldDisabled = String(!!el.disabled);
      el.dataset.qlShieldTabindex = el.getAttribute("tabindex") || "";
      el.setAttribute("tabindex", "-1");
      if (el.tagName !== "DIV" && "disabled" in el) el.disabled = true;
      if (el.contentEditable === "true") {
        el.contentEditable = "false";
        el.dataset.qlShieldEditable = "true";
      }
    });
    return true;
  }

  function setNativeChatActive(active) {
    injectLiteStyles();
    qlNativeEnabled = !!active;
    var chatForm = getChatForm();
    if (!active) {
      var badge = document.getElementById("ql-native-badge");
      if (badge) badge.remove();
      var sendBtnOff = document.getElementById("chatinput-send-message-button");
      if (sendBtnOff) sendBtnOff.classList.remove("ql-native-send-active");
      var floatingOff = document.getElementById("ql-floating");
      if (floatingOff) floatingOff.style.display = "";
      return true;
    }
    if (!chatForm) {
      if (qlNativeRetry++ < 20) setTimeout(function () { setNativeChatActive(true); }, 500);
      return false;
    }
    qlNativeRetry = 0;
    if (getComputedStyle(chatForm).position === "static") chatForm.style.position = "relative";
    // Keep floating dock visible in native mode — user only has one chat.
    if (!document.getElementById("ql-native-badge")) {
      var badgeEl = document.createElement("div");
      badgeEl.id = "ql-native-badge";
      badgeEl.className = "ql-native-badge";
      badgeEl.textContent = "⚡ Lovable Pro";
      badgeEl.title = "Enviado com Lovable Pro";
      badgeEl.style.pointerEvents = "none";
      chatForm.appendChild(badgeEl);
    }
    var sendBtn = document.getElementById("chatinput-send-message-button") || chatForm.querySelector('button[type="submit"],button[aria-label*="send" i]');
    if (sendBtn) sendBtn.classList.add("ql-native-send-active");
    // Intercepta o envio nativo para prefixar automaticamente o texto com o banner Lovable Pro.
    installNativeSendInterceptor(chatForm);
    return true;
  }

  var qlBannerSending = false;
  function installNativeSendInterceptor(chatForm) {
    if (!chatForm || chatForm.dataset.qlBannerBound === "true") return;
    chatForm.dataset.qlBannerBound = "true";

    function prefixCurrentEditor() {
      var ed = chatForm.querySelector('[contenteditable="true"]');
      if (!ed) return false;
      var current = (ed.innerText || ed.textContent || "").trim();
      if (!current) return false;
      if (/Lovable Pro/i.test(current.split("\n")[0] || "")) return false;
      ed.focus();
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, prefixPromptWithBanner(current));
      try { ed.dispatchEvent(new Event("input", { bubbles: true })); } catch (e) {}
      return true;
    }

    // Enter no editor → prefixa antes do Lovable capturar o submit.
    chatForm.addEventListener("keydown", function (e) {
      if (qlBannerSending) return;
      if (e.key !== "Enter" || e.shiftKey || e.isComposing) return;
      var target = e.target;
      if (!target || target.getAttribute("contenteditable") !== "true") return;
      if (prefixCurrentEditor()) {
        qlBannerSending = true;
        setTimeout(function () { qlBannerSending = false; }, 800);
      }
    }, true);

    // Clique no botão de enviar → prefixa antes do envio.
    chatForm.addEventListener("click", function (e) {
      if (qlBannerSending) return;
      var btn = e.target && e.target.closest && e.target.closest("button");
      if (!btn) return;
      var isSend =
        btn.id === "chatinput-send-message-button" ||
        btn.type === "submit" ||
        /send/i.test(btn.getAttribute("aria-label") || "");
      if (!isSend) return;
      if (prefixCurrentEditor()) {
        qlBannerSending = true;
        setTimeout(function () { qlBannerSending = false; }, 800);
      }
    }, true);
  }

  async function quickProjectInit(promptText) {
    if (window.location.pathname.match(/\/projects\/[a-f0-9-]{36}/i)) {
      throw new Error("Use este botão na tela inicial do Lovable, sem projeto aberto.");
    }
    var chatForm = getChatForm();
    if (!chatForm) throw new Error("Campo do Lovable não encontrado. Abra a tela inicial do Lovable.");
    var shieldWasActive = !!document.getElementById("ql-shield-overlay");
    if (shieldWasActive) { qlShieldBypassUntil = Date.now() + 12000; setShieldActive(false); chatForm = getChatForm() || chatForm; }
    var editor = chatForm.querySelector('[contenteditable="true"]');
    if (!editor) throw new Error("Campo de texto não encontrado.");
    var buildBtn = document.getElementById("chatinput-send-message-button") || chatForm.querySelector('button[type="submit"],button[aria-label*="send" i],button:last-of-type');
    if (!buildBtn) throw new Error("Botão de criar não encontrado.");
    editor.focus();
    document.execCommand("selectAll", false, null);
    document.execCommand("insertText", false, prefixPromptWithBanner(promptText || "Crie um novo projeto Lovable em branco, pronto para começar a desenvolver."));
    try { editor.dispatchEvent(new Event("input", { bubbles: true })); } catch (e) {}
    var started = Date.now();
    while ((buildBtn.disabled || buildBtn.getAttribute("aria-disabled") === "true") && Date.now() - started < 8000) {
      await new Promise(function (r) { setTimeout(r, 250); });
    }
    if (buildBtn.disabled || buildBtn.getAttribute("aria-disabled") === "true") throw new Error("Botão de criar ainda está desativado.");
    buildBtn.click();
    if (shieldWasActive && isLovableHomePage()) setTimeout(function () { qlShieldBypassUntil = 0; setShieldActive(true); }, 1200);
    return true;
  }

  function maintainHomeShieldAndNativeChat() {
    var path = window.location.pathname || "/";
    if (path !== qlLastPath) {
      qlLastPath = path;
      qlShieldRetry = 0;
      qlNativeRetry = 0;
    }
    if (isLovableHomePage() && Date.now() > qlShieldBypassUntil) setShieldActive(true);
    else setShieldActive(false);
    if (qlNativeEnabled) setNativeChatActive(true);
  }

  function getNativeChatCaptureBody() {
    return null;
  }

  bootFloatingUI();
  try {
    chrome.storage.local.get(["ql_shield_active", "ql_native_chat"], function (res) {
      // Shield is ALWAYS auto-active on the Lovable home page — blocks sends outside the extension.
      if (isLovableHomePage()) {
        setShieldActive(true);
        try { chrome.storage.local.set({ ql_shield_active: true }); } catch (e) {}
      }
      // Chat nativo permanece SEMPRE ativo — sem opção de desligar.
      qlNativeEnabled = true;
      setNativeChatActive(true);
      try { chrome.storage.local.set({ ql_native_chat: true }); } catch (e) {}
    });
  } catch (e) {}

  // Se o usuário pediu "Criar novo projeto" fora da home, dispara aqui após carregar.
  try {
    if (isLovableHomePage()) {
      chrome.storage.local.get(["ql_pending_new_project"], function (res) {
        var pending = res && res.ql_pending_new_project;
        if (!pending || !pending.prompt) return;
        if (Date.now() - (pending.ts || 0) > 60000) {
          try { chrome.storage.local.remove(["ql_pending_new_project"]); } catch (e) {}
          return;
        }
        try { chrome.storage.local.remove(["ql_pending_new_project"]); } catch (e) {}
        setTimeout(function () {
          showToast("Enviando pedido de novo projeto…");
          quickProjectInit(pending.prompt)
            .then(function () { showToast("✓ Projeto solicitado.", "success"); })
            .catch(function (err) { showToast("✗ " + (err.message || "erro"), "error"); });
        }, 1500);
      });
    }
  } catch (e) {}
  try {
    setInterval(maintainHomeShieldAndNativeChat, 1200);
    new MutationObserver(function () { maintainHomeShieldAndNativeChat(); }).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}

  // First-run: no license stored → open the side panel to prompt for one.
  try {
    chrome.storage.local.get(["mxx_license_key", "mxx_first_prompt_shown"], function (res) {
      if (!res.mxx_license_key) {
        setTimeout(function () {
          showToast("🔑 Ative sua licença Lovable Pro.");
          openActivationModal();
        }, 900);
      }
    });
  } catch (e) {}

  chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
    if (msg && msg.action === "ping") {
      sendResponse({ ok: true, bridge: true });
      return false;
    }
    if (msg && msg.action === "qlOpenLicenseUi") {
      ensureLicenseOrPrompt();
      sendResponse({ ok: true });
      return false;
    }
    if (msg && msg.action === "qlLicenseDisconnected") {
      handleLicenseDisconnected(msg.reason || "invalid");
      sendResponse({ ok: true });
      return false;
    }
    if (msg && msg.action === "qlToggleDock") {
      try {
        var box = document.getElementById("ql-floating");
        if (!box) { buildFloatingUI(); box = document.getElementById("ql-floating"); }
        var dockEl = box && box.querySelector(".ql-dock");
        var handle = box && box.querySelector(".ql-dock-mascot");
        if (dockEl) {
          var collapsed = dockEl.classList.toggle("ql-collapsed");
          if (handle) handle.classList.toggle("ql-collapsed-pulse", collapsed);
          try { chrome.storage.local.set({ ql_dock_collapsed: collapsed }); } catch (e) {}
        }
      } catch (e) {}
      // Also surface the license/activation UI when the user clicks the toolbar icon.
      ensureLicenseOrPrompt();
      sendResponse({ ok: true });
      return false;
    }
    if (msg && msg.action === "qlActivateBypass") {
      setPkCreditBypass(true);
      sendResponse({ ok: true });
      return false;
    }
    if (msg && msg.action === "qlDeactivateBypass") {
      setPkCreditBypass(false);
      sendResponse({ ok: true });
      return false;
    }
    if (msg && msg.action === "setCreditBypass") {
      setPkCreditBypass(!!msg.active);
      sendResponse({ ok: true });
      return false;
    }
    if (msg && msg.action === "syncCreditBypass") {
      syncPkCreditBypassFromStorage();
      sendResponse({ ok: true });
      return false;
    }
    if (msg && msg.action === "qlSendViaWs") {
      deliverPromptToLovable(msg.message || "")
        .then(function () { sendResponse({ ok: true }); })
        .catch(function (err) { sendResponse({ ok: false, error: err.message || String(err) }); });
      return true;
    }
    if (msg && msg.action === "setShieldActive") {
      setShieldActive(!!msg.active);
      sendResponse({ ok: true });
      return false;
    }
    if (msg && msg.action === "setNativeChatActive") {
      qlNativeEnabled = !!msg.active;
      setNativeChatActive(qlNativeEnabled);
      sendResponse({ ok: true });
      return false;
    }
    if (msg && (msg.action === "qlActivateNativeChat" || msg.action === "activateNativeChat")) {
      qlNativeEnabled = true;
      setNativeChatActive(true);
      sendResponse({ ok: true });
      return false;
    }
    if (msg && (msg.action === "qlDeactivateNativeChat" || msg.action === "deactivateNativeChat")) {
      qlNativeEnabled = false;
      setNativeChatActive(false);
      sendResponse({ ok: true });
      return false;
    }
    if (msg && msg.action === "qlQuickProjectInit") {
      quickProjectInit(msg.prompt || "")
        .then(function () { sendResponse({ ok: true }); })
        .catch(function (err) { sendResponse({ ok: false, error: err.message || String(err) }); });
      return true;
    }
    if (msg && msg.action === "getNativeChatCapture") {
      sendResponse({ body: getNativeChatCaptureBody() });
      return false;
    }
    if (msg && msg.action === "requestTokenRefresh") {
      try { window.postMessage({ type: "lovableRequestToken" }, "*"); } catch (e) {}
      setTimeout(function () {
        try { window.postMessage({ type: "lovableRequestToken" }, "*"); } catch (e2) {}
      }, 120);
      sendResponse({ ok: true });
      return false;
    }
    if (msg && msg.action === "resolveLovableAuth") {
      (async function () {
        try { window.postMessage({ type: "lovableRequestToken" }, "*"); } catch (e) {}
        await new Promise(function (r) { setTimeout(r, 200); });
        var sd = await new Promise(function (r) {
          chrome.storage.local.get(["lovable_token", "lovable_projectId"], r);
        });
        sendResponse({
          token: sd.lovable_token || "",
          projectId: projectIdFromPage() || sd.lovable_projectId || ""
        });
      })();
      return true;
    }
  });
})();
