# Lovable Pro — Extensão Chrome

Companion Chrome (MV3) extension for [Lovable.dev](https://lovable.dev):
license-gated side panel, prompt asset uploads, and lightweight analytics.

Esta é a extensão **Lovable Pro** em Manifest V3, integrada ao painel web e aos endpoints `/api/public/*` deste projeto.

## License

MIT — see [LICENSE](./LICENSE).

## Install (unpacked)

1. Download and unzip this archive.
2. Open `chrome://extensions` in Chrome / Edge / Brave / Arc.
3. Enable **Developer mode** (top-right).
4. Click **Load unpacked** and pick the unzipped folder.
5. Open Lovable.dev — the side panel icon appears in the toolbar.

## Project layout

| File | Purpose |
| --- | --- |
| `manifest.json` | MV3 manifest, host permissions, side-panel registration |
| `background.js` | Service worker: license API, fetch proxy, message routing |
| `sidepanel.{html,js,css}` | Side panel UI (license gate, dashboard, settings) |
| `license-gate.js` | Activation gate calling `/api/public/validate-license` |
| `content.js` / `content-bridge.js` | Lovable.dev DOM integration |
| `pageHook.js` | Page-world hook (token capture, network instrumentation) |
| `lovable-auth.js` / `lovable-feature-api.js` | Lovable token + feature helpers |
| `extension-config.js` | API base URL and feature flags |
| `user-messages.js` | Human-readable error translation |
| `sounds.js` | Soft audio cues for success / error states |
| `jszip.min.js` | Vendored ZIP helper for bulk uploads |
| `assets/` | Icons & logo PNGs |

## Configuration

`extension-config.js` defines the backend base URL:

```js
var API_BASE = "https://lovablepromaxss.lovable.app";
```

Point it at your own deployment if you self-host the dashboard.

O ZIP gerado pelo painel fala com o backend configurado em `extension-config.js` e usa o mesmo formato de licença do painel admin.

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md). PRs welcome.
